/** App-level constants*/
export default {
    EVENTS: {
        TYPES: {
            FONT: 'FONT',
            REFRESH: 'REFRESH',
            STYLE: 'STYLE',
        },
        PRIORITY: {
            LOW: 1,
            MEDIUM: 5,
            HIGH: 10,
        },
        SDK: {
            READY: 'sdk-ready',
            NOT_READY: 'sdk-not-ready',
        }
    },
};
