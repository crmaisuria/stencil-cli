import 'ng-idle';

import sessionConfig from './session.config.js';
import sessionConstants from './session.constants.js';
import SessionService from './session.service.js';

export default angular.module('ng-stencil-editor.session', [])
    .config(sessionConfig)
    .constant('SESSION', sessionConstants)
    .service('sessionService', SessionService);
