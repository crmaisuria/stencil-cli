import SessionModalCtrl from './session.service.js';

export default class SessionService {
    /*@ngInject*/
    constructor($http, $modal, $q, $rootScope, $window, Idle, BC_SEED_DATA, SESSION) {
        this._$http = $http;
        this._$modal = $modal;
        this._$q = $q;
        this._$rootScope = $rootScope;
        this._$window = $window;
        this._Idle = Idle;
        this._oauthBaseUrl = BC_SEED_DATA.oauthBaseUrl;
        this._SESSION = SESSION;
        this._warningModal = null;
    }

    closeIdleWarningModal() {
        if (this._warningModal) {
            this._warningModal.close();
        }
    }

    heartbeat() {
        return this._$http.jsonp(this._oauthBaseUrl + '/session/heartbeat?callback=JSON_CALLBACK')
            .then(resp => resp.data);
    }

    keepAliveResponse(event, data = {}) {
        if (data.status === 'ALIVE') {
            // Ping A&A to make sure it knows we are still alive
            this.heartbeat()
                .then(resp => {
                    if (!resp.ok) {
                        this.logOut();
                    }
                })
                .catch(() => this.logOut());
        } else {
            this.logOut();
        }
    }

    logOut() {
        return this._$http
            .get(this._SESSION.PHP_LOGOUT_URL)
            .then(() => this._$http.jsonp(this._oauthBaseUrl + '/logout?callback=JSON_CALLBACK'))
            .finally(() => this.reloadPage());
    }

    openIdleWarningModal() {
        this._warningModal = this._$modal.open({
            controller: SessionModalCtrl,
            controllerAs: 'sessionModalCtrl',
            templateUrl: 'app/session/session.tpl.html',
            windowClass: 'modal'
        });

        return this._warningModal;
    }

    registerIdleHandlers() {
        this._$rootScope.$on('KeepaliveResponse', _.bind(this.keepAliveResponse, this));
        this._$rootScope.$on('IdleStart', _.bind(this.openIdleWarningModal, this));
        this._$rootScope.$on('IdleEnd', _.bind(this.closeIdleWarningModal, this));
        this._$rootScope.$on('IdleTimeout', _.bind(this.logOut, this));

        this._Idle.watch();
    }

    registerIdleTimeout(callback) {
        this._idleTimeoutCallback = callback;
    }

    reloadPage() {
        this._$window.removeEventListener('beforeunload', this._idleTimeoutCallback, false);
        this._$window.location.reload();
    }
}
