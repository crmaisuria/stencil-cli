import 'angular';
import 'angular-mocks';
import 'ng-idle';

import sessionModule from './session.module.js';

describe('SessionService: ', () => {
    const BC_SEED_DATA = {
        oauthBaseUrl: 'http://login.bcservices.dev'
    };

    let $httpBackend;
    let $q;
    let $rootScope;
    let sessionService;

    beforeEach(() => {
        angular.mock.module('ngIdle');
        angular.mock.module('ng-stencil-editor.session');
        angular.mock.module({
            $modal: angular.noop
        });
    });

    beforeEach(module(sessionModule.name));

    beforeEach(inject($injector => {
        $httpBackend = $injector.get('$httpBackend');
        $q = $injector.get('$q');
        $rootScope = $injector.get('$rootScope');
        sessionService = $injector.get('sessionService');
    }));

    beforeEach(() => {
        sessionService._oauthBaseUrl = BC_SEED_DATA.oauthBaseUrl;
        sessionService._$modal.open = angular.noop;
    });

    describe('heartbeat() method', () => {
        beforeEach(() => {
            $httpBackend.expectJSONP(sessionService._oauthBaseUrl + '/session/heartbeat?callback=JSON_CALLBACK')
                .respond(200, { data: {
                    ok: true
                }});
        });

        afterEach(() => {
            $httpBackend.verifyNoOutstandingExpectation();
            $httpBackend.verifyNoOutstandingRequest();
        });

        it('should call A&As heartbeat JSONP endpoint', () => {
            sessionService.heartbeat();
            $httpBackend.flush();
        });
    });

    describe('keepAliveResponse() method', () => {
        it('should call logOut() if the request fails', () => {
            spyOn(sessionService, 'heartbeat').and.returnValue($q.reject());
            spyOn(sessionService, 'logOut');

            sessionService.keepAliveResponse(null, { status: 'ALIVE' });

            $rootScope.$apply();

            expect(sessionService.logOut).toHaveBeenCalled();
        });

        it('should call logout() if the request succeeds and ok is false', () => {
            spyOn(sessionService, 'heartbeat').and.returnValue($q.when({ ok: false }));
            spyOn(sessionService, 'logOut');

            sessionService.keepAliveResponse(null, { status: 'ALIVE' });

            $rootScope.$apply();

            expect(sessionService.logOut).toHaveBeenCalled();
        });

        it('should call logout() if the status is not ALIVE', () => {
            spyOn(sessionService, 'logOut');

            sessionService.keepAliveResponse(null, { status: 'NOT-ALIVE' });

            $rootScope.$apply();

            expect(sessionService.logOut).toHaveBeenCalled();
        });
    });

    describe('registerIdleHandlers() method', () => {
        it('should start the idle watcher', () => {
            spyOn(sessionService._Idle, 'watch');

            sessionService.registerIdleHandlers();

            expect(sessionService._Idle.watch).toHaveBeenCalled();
        });
    });

    describe('registerIdleTImeout', () => {
        it('should set idleTimeoutCallback', () => {
            const testFunc = angular.noop;

            sessionService.registerIdleTimeout(testFunc);

            expect(sessionService._idleTimeoutCallback).toBe(testFunc);
        });
    });

    describe('reloadPage()', () => {

        beforeEach(() => {
            sessionService._$window = {
                removeEventListener: jasmine.createSpy('removeEventListener'),
                location: { reload: jasmine.createSpy('reload') }
            };
        });
        it('should remove the beforeunload event', () => {
            const testFunc = angular.noop;

            sessionService._idleTimeoutCallback = testFunc;
            sessionService.reloadPage();

            expect(sessionService._$window.removeEventListener).toHaveBeenCalledWith(
                'beforeunload',
                testFunc,
                false
            );
        });

        it('should reload the page', () => {
            sessionService.reloadPage();

            expect(sessionService._$window.location.reload).toHaveBeenCalled();
        });
    });
});
