import 'angular';
import 'angular-mocks';

import apiModule from 'src/app/app.api.js';
import servicesModule from './services.module.js';
import versionMock from 'tests/mocks/version.mock.js';

describe('VersionService: ', () => {
    const versionId = versionMock.id;

    let $httpBackend;
    let API;
    let versionService;

    beforeEach(module(apiModule.name));
    beforeEach(module(servicesModule.name));

    beforeEach(inject(function ($injector) {
        $httpBackend = $injector.get('$httpBackend');
        API = $injector.get('API');
        versionService = $injector.get('versionService');
    }));

    describe('fetchVersion() method', () => {
        beforeEach(() => {
            $httpBackend.expectGET(API.VERSION_PATH + '/' + versionId).respond(200, { data: versionMock });
        });

        afterEach(() => {
            $httpBackend.verifyNoOutstandingExpectation();
            $httpBackend.verifyNoOutstandingRequest();
        });

        it('should fetch the specified version', () => {
            versionService.fetchVersion(versionId);

            $httpBackend.flush();
        });

        it('should call setVersion with the version object', () => {
            spyOn(versionService, 'setVersion').and.callThrough();

            versionService.fetchVersion(versionId);

            $httpBackend.flush();

            expect(versionService.setVersion).toHaveBeenCalledWith(versionMock);
        });

        it('should call mapFieldsets method with the editor schema', () => {
            spyOn(versionService, 'mapFieldsets').and.callThrough();

            versionService.fetchVersion(versionId);

            $httpBackend.flush();

            expect(versionService.mapFieldsets).toHaveBeenCalledWith(versionMock.editorSchema);
        });

        it('should call setFieldsets', () => {
            spyOn(versionService, 'setFieldsets').and.callThrough();

            versionService.fetchVersion(versionId);

            $httpBackend.flush();

            expect(versionService.setFieldsets).toHaveBeenCalled();
        });
    });

    describe('getFieldsets() method', () => {
        it('should return the fieldsets', () => {
            const testFieldsets = [1, 2, 3, 4];

            versionService._fieldsets = testFieldsets;

            expect(versionService.getFieldsets()).toBe(testFieldsets);
        });
    });

    describe('getVersion() method', () => {
        it('should return the version', () => {
            const version = 'test version';

            versionService._version = version;

            expect(versionService.getVersion()).toBe(version);
        });
    });

    describe('mapFieldsets() method', () => {
        it('should return an array of fieldsets', () => {
            const formlySchema = [{
                fieldGroup: ['Field'],
                templateOptions: { name: 'Test Fieldset' },
                wrapper: 'fieldset'
            }];

            const schema = [{
                name: 'Test Fieldset',
                settings: ['Field']
            }];

            spyOn(versionService, 'mapField').and.callFake(setting => setting);

            expect(versionService.mapFieldsets(schema)).toEqual(formlySchema);
        });
    });

    describe('mapField() method', () => {
        it('should change the type from text to input', () => {
            const field = { type: 'text' };

            expect(versionService.mapField(field).type).toBe('input');
        });

        it('should change the type from image to upload', () => {
            const field = { type: 'image' };

            expect(versionService.mapField(field).type).toBe('upload');
        });

        it('should return a structured field', () => {
            const field = {
                content: 'Test Content',
                force_reload: false,
                id: 1,
                label: 'Test Label',
                max: 10,
                min: 1,
                options: ['Test Option 1', 'Test Option 2'],
                placeholder: 'Test Placeholder',
                step: 'Test Step',
                type: 'text',
            };

            expect(versionService.mapField(field)).toEqual({
                key: field.id,
                type: 'input',
                data: {
                    content: field.content,
                    forceReload: field.force_reload
                },
                templateOptions: {
                    label: field.label,
                    max: field.max,
                    min: field.min,
                    options: field.options,
                    placeholder: field.placeholder,
                    step: field.step,
                    type: field.type
                }
            });
        });
    });
});
