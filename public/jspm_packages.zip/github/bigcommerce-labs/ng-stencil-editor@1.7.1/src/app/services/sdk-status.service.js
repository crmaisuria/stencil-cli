export default class SdkStatusService {
    /*@ngInject*/
    constructor($timeout, eventQueueService) {
        this._$timeout = $timeout;
        this._eventQueueService = eventQueueService;
        this._isReady = false;
    }

    isReady(status) {
        if (!_.isUndefined(status)) {
            this._isReady = status;
        }

        return this._isReady;
    }

    handleSdkReady() {
        this._$timeout(() => {
            if (!this._eventQueueService.isEmpty()) {
                return this._eventQueueService.dequeue().callback();
            }

            return this.isReady(true);
        });
    }
}
