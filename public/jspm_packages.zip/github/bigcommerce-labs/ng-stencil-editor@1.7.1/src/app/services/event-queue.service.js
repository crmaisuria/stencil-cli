export default class EventQueueService {
    /*@ngInject*/
    constructor() {
        this._queue = [];
    }

    clear() {
        this._queue.length = 0;

        return this._queue;
    }

    containsType(type) {
        return !!_.find(this._queue, { type });
    }

    dequeue() {
        return this._queue.shift();
    }

    enqueue(event) {
        this._queue = _.chain(this._queue)
            .push(event)
            .sortBy(event => event.priority * -1) // sort priority from high to low while preserving stability
            .value();

        return this._queue;
    }

    enqueueUnique(event) {
        if (!this.containsType(event.type)) {
            return this.enqueue(event);
        }

        return this._queue;
    }

    isEmpty() {
        return this._queue.length === 0;
    }

}
