import 'angular';
import 'angular-mocks';

import SdkStatusService from './sdk-status.service.js';

describe('SdkReady Service: ', () =>  {
    function createService() {
        return new SdkStatusService();
    }

    describe('isReady method', () => {
        it('should get the internal _isReady value (default false) when no argument supplied', () => {
            const sdkStatusService = createService();

            expect(sdkStatusService.isReady()).toBe(false);
        });

        it('should set the internal _isReady value if an argument is supplied', () => {
            const sdkStatusService = createService();

            sdkStatusService.isReady(true);

            expect(sdkStatusService.isReady()).toBe(true);
        });
    });
});
