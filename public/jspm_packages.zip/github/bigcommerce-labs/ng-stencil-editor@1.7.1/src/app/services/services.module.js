import ChannelService from 'src/app/services/channel.service.js';
import ConfigService from 'src/app/services/config.service.js';
import EventQueueService from 'src/app/services/event-queue.service.js';
import FontsService from 'src/app/services/fonts.service.js';
import SdkStatusService from 'src/app/services/sdk-status.service.js';
import VariationService from 'src/app/services/variation.service.js';
import VersionService from 'src/app/services/version.service.js';

export default angular.module('ng-stencil-editor.services', [])
    .service('channelService', ChannelService)
    .service('configService', ConfigService)
    .service('eventQueueService', EventQueueService)
    .service('fontsService', FontsService)
    .service('sdkStatusService', SdkStatusService)
    .service('variationService', VariationService)
    .service('versionService', VersionService);
