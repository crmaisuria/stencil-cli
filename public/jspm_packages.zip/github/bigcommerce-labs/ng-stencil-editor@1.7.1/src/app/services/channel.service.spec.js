import 'angular';
import 'angular-mocks';

import servicesModule from './services.module.js';

describe('ChannelService: ', () => {
    let channelService;

    beforeEach(module(servicesModule.name));

    beforeEach(inject(function ($injector) {
        channelService = $injector.get('channelService');

        channelService._$window = {
            Channel: {
                build: jasmine.createSpy('build')
            }
        };
    }));

    describe('createChannel() method', () => {
        it('should call $window.Channel.build with the passed options', () => {
            const options = { test: 'options' };

            channelService.createChannel(options);

            expect(channelService._$window.Channel.build).toHaveBeenCalledWith(options);
        });
    });

    describe('emit() method', () => {
        it('should make a channel call with the expected options', () => {
            const data = { test: 'data' };
            const name = 'TestMethodName';

            channelService._channel = {
                call: jasmine.createSpy('call')
            };

            channelService.emit(name, { data });

            expect(channelService._channel.call).toHaveBeenCalledWith({
                method: name,
                params: JSON.stringify(data),
                error: angular.noop,
                success: angular.noop
            });
        });
    });
});
