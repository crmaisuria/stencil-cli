import 'angular';
import 'angular-mocks';

import EventQueueService from './event-queue.service.js';

describe('SdkReady Service: ', () =>  {
    const PRIORITY = {
        LOW: 1,
        MEDIUM: 2,
        HIGH: 3,
    };

    function createService() {
        return new EventQueueService();
    }

    function makeQueueEvent(type = 'STYLE', priority = 2, callback = _.noop) {
        return { type, priority, callback };
    }

    describe('clear method', () => {
        it('should remove everything in the queue and return the empty queue', () => {
            const eventQueueService = createService();

            // set internal queue directly with mocks
            eventQueueService._queue = [makeQueueEvent(), makeQueueEvent(), makeQueueEvent()];

            expect(eventQueueService.clear().length).toEqual(0);
        });
    });

    describe('containsType method', () => {
        it('should check whether there is a queued event with the specified type', () => {
            const eventQueueService = createService();

            eventQueueService._queue = [makeQueueEvent('FOO')];
            expect(eventQueueService.containsType('FOO')).toBe(true);

            eventQueueService._queue = [makeQueueEvent('FOO')];
            expect(eventQueueService.containsType('BAR')).toBe(false);
        });

        it('should handle empty queue cases', () => {
            const eventQueueService = createService();

            eventQueueService._queue = [];
            expect(eventQueueService.containsType('FOO')).toBe(false);
        });

        it('should handle multiple items in queue cases', () => {
            const eventQueueService = createService();

            eventQueueService._queue = [makeQueueEvent(), makeQueueEvent('FOO')];
            expect(eventQueueService.containsType('FOO')).toBe(true);

            eventQueueService._queue = [makeQueueEvent(), makeQueueEvent('FOO')];
            expect(eventQueueService.containsType('BAR')).toBe(false);
        });
    });

    describe('dequeue method', () => {
        it('should return the first item in the queue', () => {
            const eventQueueService = createService();

            eventQueueService._queue = [makeQueueEvent('FOO'), makeQueueEvent('BAR')];

            expect(eventQueueService.dequeue().type).toBe('FOO');
            expect(eventQueueService._queue.length).toBe(1);
        });

        it('should return undefined for an empty queue', () => {
            const eventQueueService = createService();

            eventQueueService._queue = [makeQueueEvent('FOO'), makeQueueEvent('BAR')];

            expect(eventQueueService.dequeue().type).toBe('FOO');

        });
    });

    describe('enqueue method', () => {
        it('should return the queue containing the newly added event', () => {
            const eventQueueService = createService();
            const queueEvent = makeQueueEvent();

            expect(eventQueueService.enqueue(queueEvent)).toEqual([queueEvent]);
        });

        it('should add the event to the queue, sorted by priority', () => {
            const eventQueueService = createService();
            const eventLow = makeQueueEvent('STYLE', PRIORITY.LOW);
            const eventMedium = makeQueueEvent('STYLE', PRIORITY.MEDIUM);
            const eventHigh = makeQueueEvent('STYLE', PRIORITY.HIGH);

            expect(eventQueueService.enqueue(eventMedium)).toEqual([eventMedium]);
            expect(eventQueueService.enqueue(eventHigh)).toEqual([eventHigh, eventMedium]);
            expect(eventQueueService.enqueue(eventLow)).toEqual([eventHigh, eventMedium, eventLow]);
        });

        it('should preserve order of entry for same priority events', () => {
            const eventQueueService = createService();
            const eventHigh = makeQueueEvent('STYLE', PRIORITY.HIGH);
            const eventLow1 = makeQueueEvent('STYLE', PRIORITY.LOW);
            const eventLow2 = makeQueueEvent('STYLE', PRIORITY.LOW);
            const eventLow3 = makeQueueEvent('STYLE', PRIORITY.LOW);

            expect(eventQueueService.enqueue(eventLow1)).toEqual([eventLow1]);
            expect(eventQueueService.enqueue(eventLow2)).toEqual([eventLow1, eventLow2]);
            expect(eventQueueService.enqueue(eventHigh)).toEqual([eventHigh, eventLow1, eventLow2]);
            expect(eventQueueService.enqueue(eventLow3)).toEqual([eventHigh, eventLow1, eventLow2, eventLow3]);
        });
    });

    describe('enqueueUnique method', () => {
        it('should enqueue the event only if there isn\'t an event with the same type already in the queue ', () => {
            const eventQueueService = createService();
            const eventTypeSame1 = makeQueueEvent('SAME');
            const eventTypeSame2 = makeQueueEvent('SAME');
            const eventTypeUnique = makeQueueEvent('UNIQUE');

            eventQueueService._queue = [];

            expect(eventQueueService.enqueueUnique(eventTypeSame1).length).toEqual(1);
            expect(eventQueueService.enqueueUnique(eventTypeSame2).length).toEqual(1);
            expect(eventQueueService.enqueueUnique(eventTypeUnique).length).toEqual(2);
        });
    });

    describe('isEmpty method', () => {
        it('should return true and false for empty and not empty queue, respectively', () => {
            const eventQueueService = createService();
            const queueEvent = makeQueueEvent();

            eventQueueService._queue = [];

            expect(eventQueueService.isEmpty()).toBe(true);

            eventQueueService._queue = [queueEvent];
            expect(eventQueueService.isEmpty()).toBe(false);
        });
    });
});
