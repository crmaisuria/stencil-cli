export default class VariationService {
    /*@ngInject*/
    constructor($http, API, BC_APP_CONFIG) {
        this._$http = $http;
        this._API = API;
        this._BC_APP_CONFIG = BC_APP_CONFIG;
        this._activeVariation = {};
        this._currentVariation = {};
        this._variations = [];
    }

    fetchVariation(variationId) {
        let variation;

        return this._$http.get(this._API.VARIATION_PATH + '/' + variationId)
            .then(resp => resp.data.data)
            .then(resp => variation = resp)
            .then(resp => this.setVariations(resp.relatedVariations))
            .then(resp => this.findCurrentVariation(resp))
            .then(resp => this.currentVariation(resp))
            .then(() => this.activeVariation(variation));
    }

    fetchVariations() {
        return this._$http.get(this._API.VARIATION_PATH)
            .then(resp => resp.data.data)
            .then(resp => this.setVariations(resp));
    }

    activeVariation(variation) {
        if (variation) {
            this._activeVariation = variation;
        }

        return this._activeVariation;
    }

    currentVariation(variation) {
        if (variation) {
            this._currentVariation = variation;
        }

        return this._currentVariation;
    }

    findCurrentVariation(relatedVariations) {
        return _.find(relatedVariations, { isCurrent: true }) || {};
    }

    getVariations() {
        return this._variations;
    }

    setVariations(variations) {
        this._variations = variations;

        return variations;
    }

    updateCurrentVariation(config) {
        const activeVariation = this.activeVariation();

        activeVariation.configurationId = config.id;

        return this.currentVariation(activeVariation);
    }
}
