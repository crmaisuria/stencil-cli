import './templates.js';
import appApi from './app.api.js';
import appConfig from './app.config.js';
import appConstants from './app.constants.js';
import appRun from './app.run.js';

import filtersModule from './filters/filters.module.js';
import sessionModule from './session/session.module.js';
import stencilEditorModule from './stencil-editor/stencil-editor.module.js';
import directivesModule from './directives/directives.module.js';
import providersModule from './providers/providers.module.js';
import servicesModule from './services/services.module.js';

export default angular
    .module('ng-stencil-editor', [
        //app dependencies
        'ng-common',
        'bcapp-pattern-lab',
        'ng-stencil-editor.templates',

        //third-party dependencies
        'formly',
        'gettext',
        'ui.router',
        'ngCookies',
        'ngIdle',

        //directives
        directivesModule.name,

        //providers
        providersModule.name,

        //services
        servicesModule.name,

        //constants
        appApi.name,

        //child modules
        sessionModule.name,
        stencilEditorModule.name,

        //filters
        filtersModule.name
    ])
    .config(appConfig)
    .constant(appConstants)
    .run(appRun);
