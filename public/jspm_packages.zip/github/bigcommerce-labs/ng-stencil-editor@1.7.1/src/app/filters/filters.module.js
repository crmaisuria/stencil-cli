import countdownFilter from './countdown.filter.js';

export default angular.module('ng-stencil-editor.filters', [])
    .filter('countdown', countdownFilter);
