export default function countdownFilter() {
    return function(seconds) {
        if (!seconds) {
            return '';
        }

        let secondsLeft = Math.floor(seconds % 60);
        let minutesLeft = Math.floor((seconds / 60) % 60);

        return minutesLeft + ':' + (secondsLeft < 10 ? '0' + secondsLeft : secondsLeft);
    };
}
