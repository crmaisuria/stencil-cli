import BaseModalCtrl from 'src/app/modals/base-modal.controller.js';

export default class extends BaseModalCtrl {}
