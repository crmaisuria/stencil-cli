export default class BaseModalCtrl {
    /*@ngInject*/
    constructor($modalInstance) {
        this._$modalInstance = $modalInstance;
    }

    ok($event, data = {}) {
        $event.preventDefault();

        this._$modalInstance.close(data);
    }

    cancel($event, data = {}) {
        $event.preventDefault();

        this._$modalInstance.dismiss(data);
    }
}
