export default class StencilPreviewCtrl {
    /*@ngInject*/
    constructor($sce, BC_APP_CONFIG, configService, sdkStatusService, previewControls, versionService) {
        this._$sce = $sce;
        this._BC_APP_CONFIG = BC_APP_CONFIG;
        this._configService = configService;
        this._sdkStatusService = sdkStatusService;
        this._previewControls = previewControls;
        this._versionService = versionService;
    }

    getSize() {
        return this._previewControls.getSize();
    }

    getIframeUrl() {
        if (!this._iframeUrl) {
            // On first load, add the config id to the url, which is used to redirect and add a cookie for
            // the preview. Subsequent changes/previews will update the cookie value via the SDK.
            this._iframeUrl = this._$sce.trustAsResourceUrl(
                this._BC_APP_CONFIG.config.ShopPath + '?stencilEditor=' + this._versionService.getVersion().id + '@' + this._configService.getConfig().id
            );
        }

        return this._iframeUrl;
    }

    isFlipped() {
        return this._previewControls.isFlipped();
    }

    isReady() {
        return this._sdkStatusService.isReady();
    }

    refreshIframe() {
        return this._configService.refreshIframe();
    }

    requiresRefresh() {
        return this._configService.requiresRefresh();
    }
}
