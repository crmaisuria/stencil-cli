import 'src/app/templates.js';
import stencilEditorConfig from './stencil-editor.config.js';

export default angular.module('ng-stencil-editor.stencil-editor', [])
    .config(stencilEditorConfig);
