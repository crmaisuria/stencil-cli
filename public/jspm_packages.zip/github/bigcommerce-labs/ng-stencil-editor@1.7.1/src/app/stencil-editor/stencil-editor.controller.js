import CliNotAvailableModalCtrl from 'src/app/modals/cli-not-available-modal/cli-not-available-modal.controller.js';
import ConfirmClearModalCtrl from 'src/app/modals/confirm-clear-modal/confirm-clear-modal.controller.js';
import ConfirmPublishModalCtrl from 'src/app/modals/confirm-publish-modal/confirm-publish-modal.controller.js';
import ConfirmResetModalCtrl from 'src/app/modals/confirm-reset-modal/confirm-reset-modal.controller.js';
import UnhandledErrorModalCtrl from 'src/app/modals/unhandled-error-modal/unhandled-error-modal.controller.js';

export default class StencilEditorCtrl {
    /*@ngInject*/
    constructor($modal, $q, $timeout, BC_APP_CONFIG, EVENTS, channelService, configService, eventQueueService, flashMessages, fontsService, gettextCatalog, sdkStatusService, variationService, versionService) {
        const config = configService.getConfig();
        const fieldsets = versionService.getFieldsets();
        const version = versionService.getVersion();

        this._$modal = $modal;
        this._$q = $q;
        this._$timeout = $timeout;
        this._BC_APP_CONFIG = BC_APP_CONFIG;
        this._EVENTS = EVENTS;
        this._channelService = channelService;
        this._configService = configService;
        this._flashMessages = flashMessages;
        this._eventQueueService = eventQueueService;
        this._fontsService = fontsService;
        this._gettextCatalog = gettextCatalog;
        this._sdkStatusService = sdkStatusService;
        this._variationService = variationService;
        this._versionService = versionService;

        // Set initial data on the controller
        this.config = config;
        this.fieldsets = fieldsets;
        this.version = version;

        // Clean up and watch all our fields
        this.cleanFields(fieldsets, config);
        this.changeFields(fieldsets);

        // Inject the initial fonts for the current configuration settings
        this._fontsService.setInitialFonts(config.settings);
    }

    apply() {
        return this._$modal
            .open({
                controller: ConfirmPublishModalCtrl,
                controllerAs: 'confirmPublishModalCtrl',
                templateUrl: 'app/modals/confirm-publish-modal/confirm-publish-modal.tpl.html',
                windowClass: 'modal'
            })
            .result.then(() => {
                const successMessage = this._gettextCatalog.getString('Variation was successfully applied to your store.');

                return this._configService.publish(this.config)
                    .then(config => this._variationService.updateCurrentVariation(config))
                    .then(() => this._flashMessages.success(successMessage))
                    .then(() => this.resetForm())
                    .catch(error => this.openErrorModal(error));
            });
    }

    clear() {
        return this._$modal
            .open({
                controller: ConfirmClearModalCtrl,
                controllerAs: 'confirmClearModalCtrl',
                templateUrl: 'app/modals/confirm-clear-modal/confirm-clear-modal.tpl.html',
                windowClass: 'modal'
            })
            .result.then(() => {
                return this._configService.clear()
                    .then(() => this._configService.refreshIframe())
                    .then(() => this.resetForm());
            });
    }

    changeFields(fieldsets = []) {
        // Add a change handler to every field in every fieldset
        _.each(fieldsets, fieldset => {
            _.each(fieldset.fieldGroup, field => {
                field.templateOptions.onChange = _.bind(this.onFieldChange, this);
            });
        });
    }

    cleanFields(fieldsets = [], config = {}) {
        const settings = config.settings;

        // Exclude input fields that have no corresponding configuration key
        return _.each(fieldsets, fieldset => {
            fieldset.fieldGroup = _.filter(fieldset.fieldGroup, field => {
                return field.data.content || (field.key && !_.isUndefined(settings[field.key]));
            });
        });
    }

    enqueueOrRun(event, unique = false) {
        if (this._eventQueueService.isEmpty() && this._sdkStatusService.isReady()) {
            return event.callback();
        }

        return unique ?
            this._eventQueueService.enqueueUnique(event) :
            this._eventQueueService.enqueue(event);
    }

    getFontEvent(value) {
        return {
            priority: this._EVENTS.PRIORITY.MEDIUM,
            type: this._EVENTS.TYPES.FONT,
            callback: () => this._fontsService.addFont(value),
        };
    }

    getRefreshEvent() {
        const config = this._configService.getConfig();

        return {
            priority: this._EVENTS.PRIORITY.HIGH,
            type: this._EVENTS.TYPES.REFRESH,
            callback: () => {
                return this._configService
                    .preview(config, { requiresRefresh: true })
                    .then(resp => resp.configurationId);
            },
        };
    }

    getStyleEvent() {
        const config = this._configService.getConfig();

        return {
            priority: this._EVENTS.PRIORITY.LOW,
            type: this._EVENTS.TYPES.STYLE,
            callback: () => {
                return this._configService
                    .preview(config, { requiresRefresh:  false })
                    .then(resp => resp.configurationId)
                    .then(configId => {
                        return this.reloadStylesheets(configId);
                    });
            },
        };
    }

    onFieldChange(value, field) {
        const requiresRefresh = field.data.forceReload;

        this._configService.hasChanges(true);

        // change requiring refresh: clear all other events then enqueue refresh event
        if (requiresRefresh) {
            this._eventQueueService.clear();

            return this.enqueueOrRun(this.getRefreshEvent());
        }

        // font change: enqueue font change followed by a style event (all font changes require stylesheet reload)
        if (field.type === 'font') {
            this.enqueueOrRun(this.getFontEvent(value));
        }

        // style change: enqueue style event
        return this.enqueueOrRun(this.getStyleEvent(), true);
    }

    openErrorModal(error = {}) {
        let options;

        if (error.status === 405) {
            options = {
                controller: CliNotAvailableModalCtrl,
                controllerAs: 'cliNotAvailableModalCtrl',
                templateUrl: 'app/modals/cli-not-available-modal/cli-not-available-modal.tpl.html',
                windowClass: 'modal'
            };
        } else {
            options = {
                controller: UnhandledErrorModalCtrl,
                controllerAs: 'unhandledErrorModalCtrl',
                templateUrl: 'app/modals/unhandled-error-modal/unhandled-error-modal.tpl.html',
                windowClass: 'modal'
            };
        }

        return this._$modal.open(options);
    }

    reloadStylesheets(configurationId) {
        this._sdkStatusService.isReady(false);

        return this._channelService.emit('reload-stylesheets', {
            data: { configurationId },
            success: () => this._sdkStatusService.handleSdkReady(),
            error: () => this._sdkStatusService.handleSdkReady(),
        });
    }

    resetForm() {
        // ensure our form is in its pristine state
        if (this.editorForm) {
            this.editorForm.$setPristine();
            this.editorForm.$setUntouched();
        }
    }

    resetVariant() {
        return this._$modal
            .open({
                controller: ConfirmResetModalCtrl,
                controllerAs: 'confirmResetModalCtrl',
                templateUrl: 'app/modals/confirm-reset-modal/confirm-reset-modal.tpl.html',
                windowClass: 'modal'
            })
            .result.then(() => {
                const activeVariation = this._variationService.activeVariation();

                this._configService
                    .reset(activeVariation)
                    .then(() => this.resetForm())
                    .catch(error => this.openErrorModal(error));
            });
    }

    submit() {
        const successMessage = this._gettextCatalog.getString('Your changes were saved successfully.');

        this._configService.save(this.config)
            .then(() => this._flashMessages.success(successMessage))
            .then(() => this.resetForm())
            .catch(error => this.openErrorModal(error));
    }

    variationChange() {
        this._configService.refreshIframe();
        this.resetForm();
    }

    variationChanging() {
        this._sdkStatusService.isReady(false);
    }
}
