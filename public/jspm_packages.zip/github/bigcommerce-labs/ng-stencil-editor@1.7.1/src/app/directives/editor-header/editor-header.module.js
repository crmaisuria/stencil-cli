import editorHeaderDirective from 'src/app/directives/editor-header/editor-header.directive.js';

export default angular.module('ng-stencil-editor.directives.editor-header', [])
    .directive('editorHeader', editorHeaderDirective);
