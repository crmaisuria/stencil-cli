export default class {
    /*@ngInject*/
    constructor ($timeout, channelService, eventQueueService, EVENTS, sdkStatusService) {
        this._$timeout = $timeout;
        this._sdkStatusService = sdkStatusService;
        this.bindEvent = channelService.bindEvent.bind(channelService);
        this.createChannel = channelService.createChannel.bind(channelService);
        this.dequeueEvent = eventQueueService.dequeue.bind(eventQueueService);
        this.EVENTS = EVENTS;
        this.handleSdkReady = sdkStatusService.handleSdkReady.bind(sdkStatusService);

        // set isReady to false for initial iframe load
        this.isReady(false);
    }

    isReady(value) {
        if (!_.isUndefined(value)) {
            this._$timeout(() => this._sdkStatusService.isReady(value));

            return value;
        }

        return this._sdkStatusService.isReady();
    }
}
