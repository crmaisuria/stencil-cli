import ThemeRelayCtrl from 'src/app/directives/theme-relay/theme-relay.controller.js';

class ThemeRelay {
    constructor() {
        this.bindToController = true;
        this.controller = ThemeRelayCtrl;
        this.controllerAs = 'themeRelayCtrl';
        this.restrict = 'A';
        this.scope = {
            themeRelay: '='
        };
    }

    link(scope, element, attrs, themeRelayCtrl) {
        init();

        function init() {
            themeRelayCtrl.createChannel({
                window: element[0].contentWindow,
                origin: '*',
                scope: 'stencilEditor',
                reconnect: true
            });

            themeRelayCtrl.bindEvent(themeRelayCtrl.EVENTS.SDK.READY, () => {
                scope.$apply(() => {
                    return themeRelayCtrl.handleSdkReady();
                });
            });

            themeRelayCtrl.bindEvent(themeRelayCtrl.EVENTS.SDK.NOT_READY, () => {
                scope.$apply(() => {
                    return themeRelayCtrl.isReady(false);
                });
            });

            // register load event listener to remove spinner whenever iframe finishes loading
            element.on('load', () => themeRelayCtrl.isReady(true));
        }
    }

    /** @ngInject */
    static directiveFactory() {
        return new ThemeRelay();
    }
}

ThemeRelay.directiveFactory.$inject = [];

export default ThemeRelay.directiveFactory;
