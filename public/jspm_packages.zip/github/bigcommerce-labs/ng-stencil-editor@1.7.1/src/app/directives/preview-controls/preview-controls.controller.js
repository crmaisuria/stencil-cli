export default class {
    /*@ngInject*/
    constructor(previewControls, configService) {
        this._previewControls = previewControls;
        this._configService = configService;
    }

    setSize(size) {
        if (this._previewControls.canFlip(size) && this._previewControls.getSize() === size) {
            this._previewControls.flip();
        }

        this._previewControls.setSize(size);
    }

    getSize() {
        return this._previewControls.getSize();
    }

    isFlipped() {
        return this._previewControls.isFlipped();
    }
}
