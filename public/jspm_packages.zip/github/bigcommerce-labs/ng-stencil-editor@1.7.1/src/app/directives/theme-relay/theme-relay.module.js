import themeRelayDirective from 'src/app/directives/theme-relay/theme-relay.directive.js';

export default angular.module('ng-stencil-editor.directives.theme-relay', [])
    .directive('themeRelay', themeRelayDirective);
