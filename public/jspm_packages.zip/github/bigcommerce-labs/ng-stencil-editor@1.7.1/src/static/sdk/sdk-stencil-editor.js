'use strict';

(function stencilEditorSDK(window, Channel, Cookies) {
    var _configurationId = '',
        // Adding a dot because cookie set by bcapp also adds a dot
        _cookieDomain = (window.location.hostname === 'localhost' ? '' : '.') + window.location.hostname,
        _cookieName = 'stencil_preview',
        _noop = function() {},
        _versionId = '';

    init();

    function init() {
        if (runningInIframe()) {
            registerEvents();
        } else {
            closePreview();
        }
    }

    /**
     * Adds a link element with the passed font url
     * @param {string} fontUrl
     * @param {object} options
     */
    function addFont(fontUrl, options) {
        var link = document.createElement('link'),
            linkLoadHandler;

        options = options || {};
        options.error = options.error || _noop;
        options.success = options.success || _noop;

        link.setAttribute('rel', 'stylesheet');
        link.setAttribute('href', fontUrl);

        linkLoadHandler = link.addEventListener('load', function newFontLoaded() {
            options.success(fontUrl);

            link.removeEventListener('load', linkLoadHandler);

            focusBody();
        });

        document.head.appendChild(link);

        return true;
    }

    /**
     * Removes the cookie and reloads the page
     */
    function closePreview() {
        Cookies.remove(_cookieName, {
            domain: _cookieDomain
        });

        reloadPage();
    }

    /**
     * Force the browser to repaint the page after a stylesheet update
     */
    function focusBody() {
        document.body.focus();
    }

    /**
     * Rewrite the cdn url to a relative path that includes the storeHash
     * @param  {string} url
     * @return {string}
     */
    function rewriteStylesheetUrl(url) {
        var cdnUrlRegex = /[-|\/](\w+)\/stencil\/(.*)/i,
            match = url.match(cdnUrlRegex),
            storeHash,
            cssPath;

        if (match) {
            storeHash = match[1];
            cssPath = match[2];

            return '/stencil/s-' + storeHash + '/' + cssPath;
        }

        return url;
    }

    /**
     * Generate a stylesheet url replacing the configId
     * and adding a query parameter with a timestamp
     * @param  {string} url
     * @param  {string} configurationId
     * @return {string}
     */
    function generateStylesheetUrl(url, configurationId) {
        var queryIndex = url.indexOf('?'),
            stylesheetUrlRegex = /^(\/stencil\/.*\/).+?(\/css\/.*)/i,
            match,
            baseUrl,
            cssPath;

        if (queryIndex !== -1) {
            url = url.substring(0, queryIndex);
        }

        url = rewriteStylesheetUrl(url);

        match = url.match(stylesheetUrlRegex);

        if (!match) {
            throw new Error('Supplied url is not a valid stylesheet url');
        }

        baseUrl = match[1];
        cssPath = match[2];

        return baseUrl + configurationId + cssPath + '?preview=' + Date.now();
    }

    /**
     * Return an array of stylesheet link elements
     * @return {array}
     */
    function getStylesheets() {
        var stylesheets = document.head.querySelectorAll('link[data-stencil-stylesheet]');

        return Array.prototype.slice.call(stylesheets);
    }

    /*
     * Registers JsChannel subscriptions
     */
    function registerEvents() {
        var cookie = Cookies.get(_cookieName).split('@'),
            chan = Channel.build({
                window: window.parent,
                origin: '*',
                onReady: emitReady,
                scope: 'stencilEditor'
            });

        // the version id & config id will already be set by the server
        // when the iframe is loaded for the first time
        _versionId = cookie[0];
        _configurationId = cookie[1];

        // Register jsChannel events
        chan.bind('add-font', addFontHandler);
        chan.bind('reload-stylesheets', reloadStylesheetsHandler);
        chan.bind('reload-page', reloadPageHandler);
        chan.bind('set-cookie', setCookieHandler);

        // Listen on fucus event and reset the preview cookie
        window.addEventListener('focus', onFocusHandler);

        window.onbeforeunload = function emitOnUnload() {
            emitNotReady();
        };

        /**
         * Emit the 'sdk-ready' event.
         * @return channel
         */
        function emitReady() {
            chan.call({
                method: 'sdk-ready',
                success: _noop,
                error: _noop
            });

            return chan;
        }

        function emitNotReady() {
            chan.call({
                method: 'sdk-not-ready',
                success: _noop,
                error: _noop
            });

            return chan;
        }

        function addFontHandler(trans, data) {
            var fontUrl = JSON.parse(data).fontUrl,
                options = {
                    error: function(message) {
                        trans.error(message);
                    },
                    success: function(message) {
                        trans.complete(message);
                    }
                };

            trans.delayReturn(true);

            return addFont(fontUrl, options);
        }

        function reloadStylesheetsHandler(trans, data) {
            var configurationId = JSON.parse(data).configurationId,
                loadedStylesheetsCount = getLoadedStylesheets().length,
                options = {
                    error: callOnce(onError),
                    // call trans.complete once after all stylesheets have been reloaded
                    success: callAfterNTimes(loadedStylesheetsCount, onSuccess)
                };

            function onError(message) {
                return trans.error(message);
            }
            function onSuccess(message) {
                return trans.complete(message);
            }

            trans.delayReturn(true);

            setCookie(configurationId);

            return reloadStylesheets(configurationId, options);

        }

        /**
         * Get the stylesheets on the page and filter for ones that are loaded.
         * @return {Array} Array of stylesheet nodes
         */
        function getLoadedStylesheets() {
            return getStylesheets().filter(function(link) {
                return !link.hasAttribute('data-is-loading');
            });
        }

        /**
         * Invoke the callback after the nth time this function has been called. See _.after in underscore or lodash.
         * @param  {Number} n The number of calls before func is invoked.
         * @param  {Function} func The callback function to invoke.
         * @return {Function} The new restricted function.
         */
        function callAfterNTimes(n, func) {
            return function callAfterFunc() {
                if (--n < 1) {
                  return func.apply(this, arguments);
                }
            };
        }

        /**
         * Creates a function that is restricted to invoking func once. Repeat calls to the function returns the value of the first invocation.
         * @param  {Function} func The callback function to invoke.
         * @return {Function} The new restricted function.
         */
        function callOnce(func) {
            var called = false,
                result;

            return function onceFunc() {
                if (!called) {
                    called = true;
                    result = func.apply(this, arguments);
                }

                return result;
            }
        }

        function reloadPageHandler() {
            return reloadPage();
        }

        function setCookieHandler(trans, data) {
            var configurationId = JSON.parse(data).configurationId;

            return setCookie(configurationId);
        }

        function onFocusHandler() {
            setCookie(_configurationId);
        }
    }

    /**
     * Reloads the current page
     * @returns {boolean}
     */
    function reloadPage() {
        document.location.reload(true);

        return true;
    }

    /**
     * Reloads stylesheets by appending Date.now() to their href
     * @returns {boolean}
     */
    function reloadStylesheets(configurationId, options) {
        options = options || {};
        options.error = options.error || _noop;
        options.success = options.success || _noop;

        getStylesheets().forEach(updateStylesheet.bind(null, configurationId, options));

        return true;
    }

    function updateStylesheet(configurationId, options, currentLink) {
        var url = currentLink.getAttribute('href'),
            newLink;

        if (!url) {
            return;
        }

        if (currentLink.hasAttribute('data-is-loading')) {
            document.head.removeChild(currentLink);
        } else {
            newLink = currentLink.cloneNode(false);

            newLink.setAttribute('href', generateStylesheetUrl(url, configurationId));
            newLink.setAttribute('data-is-loading', true);

            newLink.addEventListener('load', stylesheetLoad);
            newLink.addEventListener('error', stylesheetError);

            // Insert the new stylesheet before the old one to avoid any flash of un-styled content. The load
            // and error events only work for the initial load, which is why we replace the link on each update.
            document.head.insertBefore(newLink, currentLink);
        }

        function stylesheetLoad() {
            newLink.removeAttribute('data-is-loading');

            // Destroy any existing handlers to save memory on subsequent stylesheet changes
            newLink.removeEventListener('error', stylesheetError);
            newLink.removeEventListener('load', stylesheetLoad);


            // Remove the old stylesheet to allow the new one to take over
            document.head.removeChild(currentLink);

            options.success(url);

            focusBody();
        }

        function stylesheetError() {
            options.error(url);

            // Something went wrong with our new stylesheet, so destroy it and keep the old one
            newLink.removeEventListener('error', stylesheetError);
            newLink.removeEventListener('load', stylesheetLoad);

            document.head.removeChild(newLink);
        }
    }

    /**
     * Checks if the current window is being run inside an iframe
     * @returns {boolean}
     */
    function runningInIframe() {
        try {
            return window.self !== window.top;
        } catch(e) {
            return true;
        }
    }

    /**
     * Sets the cookie
     * @param {string} configurationId
     */
    function setCookie(configurationId) {
        _configurationId = configurationId;

        // Adding a dot because cookie set by bcapp also adds a dot
        Cookies.set(_cookieName, _versionId + '@' + configurationId, {
            domain: _cookieDomain
        });
    }

})(window, window.Channel, window.Cookies);
