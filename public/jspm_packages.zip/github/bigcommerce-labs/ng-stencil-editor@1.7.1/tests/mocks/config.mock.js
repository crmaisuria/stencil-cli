export default {
    "id": "1",
    "variationId": "1",
    "storeHash": "12345",
    "settings": {
        "homepage_new_products_count": 12,
        "homepage_featured_products_count": 8,
        "homepage_top_products_count": 8,
        "homepage_show_carousel": true,
        "homepage_new_products_column_count": 6,
        "homepage_featured_products_column_count": 4,
        "homepage_top_products_column_count": 4,
        "homepage_blog_posts_count": 3,

        "productpage_videos_count": 8,
        "productpage_reviews_count": 9,
        "productpage_related_products_count": 10,
        "productpage_similar_by_views_count": 10,

        "show_product_quick_view": true,

        "default_image_brand": "/assets/img/BrandDefault.gif",
        "default_image_product": "/assets/img/ProductDefault.gif",
        "default_image_gift_certificate": "/assets/img/GiftCertificate.png",

        "product_list_display_mode": "grid",

        "color-primary": "#4f4f4f",
        "color-primaryDark": "#454545",
        "color-primaryDarker": "#2d2d2d",
        "color-primaryLight": "#a5a5a5",

        "color-secondary": "#ffffff",
        "color-secondaryDark": "#f2f2f2",
        "color-secondaryDarker": "#f2f2f2",

        "color-highlight": "#00abc9",
        "color-highlightDark": "#f2f2f2",
        "color-highlightDarker": "#dfdfdf",

        "color-error": "#ff7d7d",
        "color-errorLight": "#ffdddd",
        "color-info": "#666666",
        "color-infoLight": "#dfdfdf",
        "color-success": "#69d66f",
        "color-successLight": "#d5ffd8",
        "color-warning": "#d4cb49",
        "color-warningLight": "#fffdea",

        "color-textBase": "#4f4f4f",
        "color-textBase--hover": "#a5a5a5",
        "color-textBase--active": "#a5a5a5",

        "color-textSecondary": "#989898",
        "color-textSecondary--hover": "#a5a5a5",
        "color-textSecondary--active": "#a5a5a5",

        "color-textLink": "#4f4f4f",
        "color-textLink--hover": "#a5a5a5",
        "color-textLink--active": "#a5a5a5",

        "color-black": "#000000",
        "color-white": "#ffffff",
        "color-whitesBase": "#f8f8f8",
        "color-grey": "#4f4f4f",
        "color-greyDarkest": "#2d2d2d",
        "color-greyDarker": "#454545",
        "color-greyDark": "#666666",
        "color-greyMedium": "#989898",
        "color-greyLight": "#a5a5a5",
        "color-greyLighter": "#dfdfdf",
        "color-greyLightest": "#f2f2f2",

        "storeName-fontColor": "#4f4f4f",
        "header-nav-fontColor": "#4f4f4f",
        "header-backgroundColor": "#ffffff",

        "navPage-subMenu-backgroundColor": "#f2f2f2",
        "navPage-subMenu-borderColor": "#dfdfdf",
        "navPage-subMenu-fontColor": "#4f4f4f",

        "body-bg": "#ffffff",
        "body-font-color": "#4f4f4f",
        "header-font-color": "#2d2d2d",
        "subheader-font-color": "#4f4f4f",
        "small-font-color": "#989898",
        "blockquote-cite-font-color": "#a5a5a5",
        "form-label-font-color": "#666666",

        "footer-heading-fontColor": "#2d2d2d",
        "footer-backgroundColor": "#ffffff",

        "buttonStyle-default-color": "#454545",
        "buttonStyle-default-colorHover": "#666666",
        "buttonStyle-default-colorActive": "#454545",
        "buttonStyle-default-backgroundColor": "#ffffff",
        "buttonStyle-default-backgroundColorHover": "#ffffff",
        "buttonStyle-default-backgroundColorActive": "#ffffff",
        "buttonStyle-default-borderColor": "#dfdfdf",
        "buttonStyle-default-borderColorHover": "#666666",
        "buttonStyle-default-borderColorActive": "#989898",

        "buttonStyle-primary-color": "#ffffff",
        "buttonStyle-primary-colorHover": "#ffffff",
        "buttonStyle-primary-colorActive": "#ffffff",
        "buttonStyle-primary-backgroundColor": "#454545",
        "buttonStyle-primary-backgroundColorHover": "#666666",
        "buttonStyle-primary-backgroundColorActive": "#989898",
        "buttonStyle-primary-borderColor": "#454545",
        "buttonStyle-primary-borderColorHover": "#666666",
        "buttonStyle-primary-borderColorActive": "#989898",

        "container-border-global-color-base": "#f2f2f2",
        "container-border-global-color-dark": "#454545",
        "container-fill-base": "#ffffff",
        "container-fill-dark": "#f2f2f2",

        "card-title-color": "#2d2d2d",
        "card-title-color-hover": "#a5a5a5",

        "navList-action-color": "#4f4f4f",

        "navUser-dropdown-menu-backgroundColor": "#ffffff",

        "dropdown--quickSearch-backgroundColor": "#f2f2f2",

        "input-font-color": "#454545",
        "input-border-color": "#f2f2f2",
        "input-bg-color": "#ffffff",
        "input-disabled-bg": "#ffffff",
        "select-bg-color": "#ffffff",

        "carousel-bgColor": "#ffffff",
        "carousel-title-color": "#2d2d2d",
        "carousel-description-color": "#2d2d2d",
        "carousel-dot-color": "#2d2d2d",
        "carousel-dot-color-active": "#666666",
        "carousel-dot-bgColor": "#ffffff",
        "carousel-arrow-color": "#989898",
        "carousel-arrow-bgColor": "#ffffff",

        "fontFamily-sans": "Karla, sans-serif",
        "fontFamily-serif": "Georgia, serif",
        "fontFamily-mono": "Menlo, monospace",
        "fontFamily-hero": "Oswald, sans-serif",

        "body-font": "Google_Karla",
        "headings-font": "Google_Open+Sans_700",

        "fontSize-root": 14,
        "fontSize-h1": 28,
        "fontSize-h2": 25,
        "fontSize-h3": 22,
        "fontSize-h4": 20,
        "fontSize-h5": 15,
        "fontSize-h6": 13
    }
};
