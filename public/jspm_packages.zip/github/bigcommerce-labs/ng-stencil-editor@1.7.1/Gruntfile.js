var gruntConfig = require(__dirname + '/node_modules/bc-grunt-tasks/default.config');

module.exports = function(grunt) {
    require('time-grunt')(grunt);
    require('load-grunt-config')(grunt, gruntConfig({
        data: {
            //transcludeDirectory: process.env.NG_STENCIL_EDITOR_TRANSCLUDE_DIR || '../stencil-cli/public/jspm_packages/github/bigcommerce-labs/ng-stencil-editor@<%= package.version %>/build',
            cssVendors: [],
            jsMocks: [
                'tests/mock-backend.js',
                'tests/mocks/*.js'
            ],
            jsVendors: [
                'bower_components/jschannel/src/jschannel.js',
            ],
            karmaVendorsMap: {
                'lodash': 'bower_components/lodash/dist/lodash.js',
                'angular': 'bower_components/angular/angular.js',
                'angular-cookies': 'bower_components/angular-cookies/angular-cookies.js',
                'angular-animate': 'bower_components/angular-animate/angular-animate.js',
                'angular-cache': 'bower_components/angular-cache/dist/angular-cache.js',
                'angular-mocks': 'bower_components/angular-mocks/angular-mocks.js',
                'angular-formly': 'bower_components/angular-formly/dist/formly.js',
                'angular-gettext': 'bower_components/angular-gettext/dist/angular-gettext.js',
                'angular-sanitize': 'bower_components/angular-sanitize/angular-sanitize.js',
                'angular-ui-router': 'bower_components/angular-ui-router/release/angular-ui-router.js',
                'api-check': 'bower_components/api-check/dist/api-check.js',
                'babel': 'node_modules/babel-core/browser.js',
                'bcapp-pattern-lab': 'bower_components/bcapp-pattern-lab/dist/js/bcapp-pattern-lab.js',
                'formly': 'bower_components/angular-formly/dist/formly.js',
                'ng-common': 'bower_components/ng-common/dist/js/ng-common.min.js',
                'ng-idle': 'bower_components/ng-idle/angular-idle.js',
                'phantomjs-polyfill': 'node_modules/phantomjs-polyfill/bind-polyfill.js',
                'systemjs': 'node_modules/systemjs/dist/system.js',
                'system-polyfills': 'node_modules/systemjs/dist/system-polyfills.js',
                'es6-module-loader': 'node_modules/es6-module-loader/dist/es6-module-loader.js'
            },
            karmaPort: 9120, // random port number dedicated to this repo's karma watch server
            useES6ModuleSystem: true
        }
    }));
};
