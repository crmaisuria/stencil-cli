angular.module('ng-common.interapp.factory', [])
    .factory('interapp', function interappFactory($window) {
        var PubSub = $window.PubSub;

        if (PubSub === undefined) {
            throw new Error('PubSub.js must be loaded for interapp to work.');
        }

        return {
            publish: function publish(message, data) {
                return PubSub.publish.call(PubSub, message, data);
            },
            publishSync: function publishSync(message, data) {
                return PubSub.publishSync.call(PubSub, message, data);
            },
            subscribe: function subscribe(message, func) {
                return PubSub.subscribe.call(PubSub, message, func);
            },
            unsubscribe: function unsubscribe(tokenOrFunction) {
                return PubSub.unsubscribe.call(PubSub, tokenOrFunction);
            }
        };
    });
