describe('Factory: interapp', function() {

    var $rootScope, interapp, PubSub;

    beforeEach(module('ng-common.interapp.factory'));

    beforeEach(inject(function($window, _$rootScope_, _interapp_) {
        $rootScope = _$rootScope_;
        interapp = _interapp_;
        PubSub = $window.PubSub;
    }));

    describe('PubSub publish, publishSync, subscribe, unsubscribe', function() {
        it ('should call publish method', function() {
            var message = 'foo',
                data = {foo: 'bar'};

            spyOn(PubSub, 'publish');

            interapp.publish(message, data);
            expect(PubSub.publish).toHaveBeenCalledWith(message, data);
        });

        it ('should call publishSync method', function() {
            var message = 'foo',
                data = {foo: 'bar'};

            spyOn(PubSub, 'publishSync');

            interapp.publishSync(message, data);
            expect(PubSub.publishSync).toHaveBeenCalledWith(message, data);
        });

        it ('should call subscribe method', function() {
            var message = 'foo',
                event = angular.noop;

            spyOn(PubSub, 'subscribe');

            interapp.subscribe(message, event);
            expect(PubSub.subscribe).toHaveBeenCalledWith(message, event);
        });

        it ('should call unsubscribe method', function() {
            var message = 'foo';

            spyOn(PubSub, 'unsubscribe');

            interapp.unsubscribe(message);
            expect(PubSub.unsubscribe).toHaveBeenCalledWith(message);
        });
    });
});
