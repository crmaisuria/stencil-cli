angular.module('ng-common.interapp', ['ng-common.interapp.factory']);
