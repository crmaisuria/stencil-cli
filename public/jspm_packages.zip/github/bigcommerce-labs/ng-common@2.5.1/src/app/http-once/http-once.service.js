angular.module('ng-common.http-once.service', [])
    .factory('httpOnce', function httpOnceService($q) {
        var promises = {},
            service = {
                cancel: cancel,
                check: check,
                create: create
            };

        function cancel(key) {
            var promise = promises[key];

            promise.resolve();
            delete promises[key];

            return promise;
        }

        function check(key) {
            return !!promises[key];
        }

        function create(key) {
            var promise = $q.defer();

            promises[key] = promise;

            return promise;
        }

        return service;
    });
