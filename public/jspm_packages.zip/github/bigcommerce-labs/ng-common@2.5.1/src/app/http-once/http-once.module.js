angular.module('ng-common.http-once', [
    'ng-common.http-once.decorator',
    'ng-common.http-once.service'
]);
