angular.module('ng-common.flash-messages.directive', [
    'ng-common.flash-messages.controller'
])
    .directive('flashMessages', function flashMessagesDirective() {
        return {
            controller: 'FlashMessagesCtrl as flashMessagesCtrl',
            restrict: 'E',
            templateUrl: 'app/flashMessages/flashMessagesDirective.tpl.html'
        };
    });
