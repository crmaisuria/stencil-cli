angular.module('ng-common.flash-messages.controller', [
    'ng-common.flash-messages.service'
])
    .controller('FlashMessagesCtrl', function flashMessagesCtrl(flashMessages) {
        var ctrl = this;

        ctrl.getMessages = flashMessages.getMessages;

        ctrl.closeAlert = function closeAlert(index) {
            ctrl.getMessages().splice(index, 1);
        };
    });
