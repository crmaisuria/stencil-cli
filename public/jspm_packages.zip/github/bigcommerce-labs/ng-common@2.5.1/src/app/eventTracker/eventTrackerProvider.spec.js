describe('Provider: eventTracker', function() {
    var trackMethod = jasmine.createSpy('Track Method');

    beforeEach(function() {
        function Tracker() {
            this.track = trackMethod;
        }
        angular.module('ng-common.bc-app', [])
            .constant('BC_APP_CONFIG', {
                eventTrackerService: new Tracker()
            });
    });

    beforeEach(module('ng-common.event-tracker.provider'));

    beforeEach(module('ng-common.bc-app'));

    describe('thirdParty service not set', function() {
        it ('should throw exception if third party service not set', inject(function($injector) {
            expect(function() {
                $injector.get('eventTracker');
            }).toThrow();
        }));
    });

    describe('thirdParty configured', function() {
        beforeEach(module(function(eventTrackerProvider) {
            function Tracker() {}

            eventTrackerProvider.setThirdPartyTrackerService(new Tracker());
        }));

        it ('should throw exception if third party service doesn\'t have track method', inject(function($injector) {
            expect(function() {
                $injector.get('eventTracker');
            }).toThrow();
        }));
    });

    describe('tracking an event', function() {
        var eventTracker;

        beforeEach(module(function(eventTrackerProvider, BC_APP_CONFIG) {
            eventTrackerProvider.setThirdPartyTrackerService(BC_APP_CONFIG.eventTrackerService);
        }));

        describe('without setting default tracker options', function() {
            beforeEach(inject(function(_eventTracker_) {
                eventTracker = _eventTracker_;
            }));

            it('should have at least a name', function() {
                expect(function() {
                    eventTracker.track();
                }).toThrow();
            });

            it('should fire track method with correct arguments', function() {
                var name = 'Track Me',
                    properties = {foo: 'bar'},
                    options = {bar: 'foo'},
                    callback = angular.noop;

                eventTracker.track(name, properties, options, callback);
                expect(trackMethod).toHaveBeenCalledWith(name, properties, options, callback);
            });
        });

        describe('with setting default tracker options', function() {
            var defaultOptions = {my: 'val'};
            beforeEach(module(function(eventTrackerProvider) {
                eventTrackerProvider.setDefaultTrackerOptions(defaultOptions);
            }));

            beforeEach(inject(function(_eventTracker_) {
                eventTracker = _eventTracker_;
            }));

            it('should fire track method with correct combined options', function() {
                var name = 'Track Me',
                    properties = {foo: 'bar'},
                    options = {bar: 'foo'},
                    callback = angular.noop,
                    combinedOptions = _.assign(defaultOptions, options);

                eventTracker.track(name, properties, options, callback);
                expect(trackMethod).toHaveBeenCalledWith(name, properties, combinedOptions, callback);
            });
        });
    });
});
