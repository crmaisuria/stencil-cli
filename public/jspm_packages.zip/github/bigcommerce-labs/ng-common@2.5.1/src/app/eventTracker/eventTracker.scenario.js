describe('eventTracker', function() {
    beforeEach(function() {
        browser.get('/examples/event-tracker/index.html');
    });

    it('should be a dummy test', function() {
        expect(true).toBeTruthy();
    });
});
