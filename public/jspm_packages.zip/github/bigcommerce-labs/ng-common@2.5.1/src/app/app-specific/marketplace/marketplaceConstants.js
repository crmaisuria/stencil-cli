angular.module('ng-common.marketplace.constants', [])
   .constant('EVENTS', {
       APP_INSTALL           : 'appInstalled',
       APP_INSTALL_STARTED   : 'appInstallStarted',
       APP_LAUNCH            : 'appLaunch',
       APP_SCREENSHOT_VIEW   : 'appScreenshotView',
       APP_SEARCH            : 'appSearch',
       APP_UNINSTALLED       : 'appUninstalled',
       MARKETPLACE_NAMESPACE : 'Marketplace.Apps.'
   })
    .constant('VERSIONS', {
        CP1             : 1,
        CP2             : 2,
        NEW_MARKETPLACE : 2
    });
