angular.module('ng-common.marketplace', [
    'ng-common.marketplace-events.service',
]);
