angular.module('ng-common.seed-data.provider', [])
    .provider('seedData', function seedDataProvider() {
        var seededData = {};

        this.put = function putSeedData(key, data) {
            seededData[key] = data;
        };

        this.$get = function seedDataFactory() {
            return {
                pluck: function pluckSeedData(key) {
                    var data = seededData[key];
                    delete seededData[key];

                    return data;
                },
                check: function checkSeedData(key) {
                    return !! seededData[key];
                }
            };
        };
    });
