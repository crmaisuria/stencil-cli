angular.module('ng-common.bc-currency', [
    'ng-common.bc-app',
    'ng-common.bc-currency.directive',
    'ng-common.bc-currency.filter',
    'ng-common.bc-currency.provider'
])
    .config(function(BC_APP_CONFIG, bcCurrencyProvider) {
        // Default symbol and symbol position to the most common values in our storefronts
        var currencyConfig = BC_APP_CONFIG && BC_APP_CONFIG.storeInfo && BC_APP_CONFIG.storeInfo.information.currency,
            currencyPosition = currencyConfig ? currencyConfig.symbol_location : 'left',
            currencySymbol = currencyConfig ? currencyConfig.symbol : '$';

        bcCurrencyProvider.setCurrencyPosition(currencyPosition);
        bcCurrencyProvider.setCurrencySymbol(currencySymbol);
    });