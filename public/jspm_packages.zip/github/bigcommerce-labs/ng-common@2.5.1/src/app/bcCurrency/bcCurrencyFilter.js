angular.module('ng-common.bc-currency.filter', [
        'ng-common.bc-currency.provider'
    ])
    .filter('bcCurrency', function bcCurrencyFilter($filter, bcCurrency) {
        var $currencyFilter = $filter('currency'),
            currencyPosition = bcCurrency.currencyPosition,
            currencySymbol = bcCurrency.currencySymbol;

        return function bcCurrencyFilterFn(amount, symbol, position) {
            // Start with properly-formatted currency without symbol, as the currency filter bases symbol
            // location on the user's current locale, which may be different than the currency's locale
            var result = $currencyFilter(amount, '');

            // Allow for defaulting and overrides
            position = position || currencyPosition;
            symbol = symbol || currencySymbol;

            if (position.toLowerCase() === 'left') {
                result = symbol + result;
            } else {
                result = result + symbol;
            }

            return result;
        };
    });
