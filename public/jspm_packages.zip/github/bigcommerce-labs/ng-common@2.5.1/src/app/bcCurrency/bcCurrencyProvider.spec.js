describe('Provider: bcCurrency', function() {
    beforeEach(module('ng-common.bc-currency.provider'));

    describe('without set values', function() {
        var bcCurrency;

        angular.module('ng-common.bc-app', [])
            .constant('BC_APP_CONFIG', {
                storeInfo: {
                    information: {
                        currency: {
                            symbol: '$',
                            symbol_location: 'left'
                        }
                    }
                }
            });

        beforeEach(module('ng-common.bc-app'));
        beforeEach(module('ng-common.bc-currency'));

        beforeEach(inject(function(_bcCurrency_) {
            bcCurrency = _bcCurrency_;
        }));

        it('should return default values', function() {
            expect(bcCurrency.currencyPosition).toEqual('left');
            expect(bcCurrency.currencySymbol).toEqual('$');
        });
    });

    describe('with set values', function() {
        var symbol = '&',
            symbolPosition = 'right',
            bcCurrency;

        beforeEach(module(function(bcCurrencyProvider) {
            bcCurrencyProvider.setCurrencyPosition(symbol);
            bcCurrencyProvider.setCurrencySymbol(symbolPosition);
        }));

        beforeEach(inject(function(_bcCurrency_) {
            bcCurrency = _bcCurrency_;
        }));

        it('should return configured vlaues', function() {
            expect(bcCurrency.currencyPosition).toEqual(symbol);
            expect(bcCurrency.currencySymbol).toEqual(symbolPosition);
        });
    });
});
