angular.module('ng-common.bc-currency.directive', [
        'ng-common.bc-currency.provider'
    ])
    .directive('bcCurrency', function bcCurrencyDirective(bcCurrency) {
        return {
            restrict: 'A',
            link: function bcCurrencyDirectiveLink(scope, element) {
                var symbolPosition = bcCurrency.currencyPosition,
                    symbolElement = angular.element('<span>');

                if (symbolPosition === 'left') {
                    element.before(symbolElement.text(bcCurrency.currencySymbol + ' '));
                } else {
                    element.after(symbolElement.text(' ' + bcCurrency.currencySymbol));
                }
            }
        };
    });