angular.module('ng-common', [
    'ngSanitize',
    'gettext',
    'ng-common.templates',
    'ng-common.flash-messages',
    'ng-common.bc-currency',
    'ng-common.cdn-path',
    'ng-common.event-tracker',
    'ng-common.event-messages',
    'ng-common.experiments',
    'ng-common.http-once',
    'ng-common.interapp',
    'ng-common.seed-data',
    'ng-common.lodash',
    'ng-common.ajax-request-status',
    'ng-common.marketplace',
    'ng-common.address'
])
    .run(function($rootElement) {
        /**
         * This will add the class `bc-ng` to the root element of each
         * application that is using `ng-common`.
         */
        $rootElement.addClass('bc-ng');
    });
