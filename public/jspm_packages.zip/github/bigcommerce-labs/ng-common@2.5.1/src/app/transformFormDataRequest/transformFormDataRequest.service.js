angular.module('ng-common.transformformdatarequest.service', ['ng-common.lodash'])
    .factory('transformFormDataRequest', function transformFormDataRequestService(_, $log, $window) {
        /*
         * Callback function for the $http service's transformRequest config property. It updates the Content-Type to
         * submit form data and takes a naive approach to serializing form data from an object.
         *
         * @param data object the data to be encoded
         * @param getHeaders function a function to retreive the headers for the requst
         * @return string
         */
        function transformRequest(data, getHeaders) {
            var headers = getHeaders();
            headers['Content-Type'] = 'application/x-www-form-urlencoded';
            return urlencodeFormData(data);
        }

        /*
         * Encodes the form data into key1=value1&key2=value2 format
         *
         * @param data object
         * @return string
         */
        function urlencodeFormData(data) {
            return _.reduce(data, function(result, parameter, key) {
                if (typeof parameter === 'object') {
                    $log.warn('transformFormDataRequest does not fully support transforming non-primitive values, strangeness may ensue.');
                }

                if (Array.isArray(parameter)) {
                    angular.forEach(parameter, function(element) {
                        result.push($window.encodeURIComponent(key) + '[]=' + $window.encodeURIComponent(element));
                    });
                } else {
                    result.push($window.encodeURIComponent(key) + '=' + $window.encodeURIComponent(parameter));
                }

                return result;
            }, []).join('&');
        }

        return transformRequest;
    });
