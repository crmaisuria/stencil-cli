angular.module('ng-common.experiments.provider', [
    'ng-common.bc-app',
    'ng-common.lodash'
])
    .provider('experiments', function experimentsProvider(_, BC_APP_CONFIG) {
        var provider = this;

        provider.$get = $get;
        provider.isExperimentOn = isExperimentOn;

        function $get() {
            var service = {
                isExperimentOn: provider.isExperimentOn
            };

            return service;
        }

        function isExperimentOn(experimentName) {
            if (_.has(BC_APP_CONFIG.experiments, experimentName)) {
                return BC_APP_CONFIG['experiments'][experimentName] === 'on';
            }

            return false;
        }
    });
