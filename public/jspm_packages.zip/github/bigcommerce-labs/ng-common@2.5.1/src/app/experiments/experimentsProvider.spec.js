describe('Provider: experiments', function() {
    var experimentsProvider,
        experimentsService;

    beforeEach(function() {
        angular.module('ng-common.bc-app', [])
            .constant('BC_APP_CONFIG', {
                experiments: {
                    'test.experiment.on': 'on',
                    'test.experiment.off': 'off',
                    'test.experiment.control': 'control'
                }
            });
    });

    beforeEach(module('ng-common.experiments.provider'));

    beforeEach(module(function(_experimentsProvider_) {
        experimentsProvider = _experimentsProvider_;
    }));

    beforeEach(inject(function($injector) {
        experimentsService = $injector.get('experiments');
    }));

    describe('experimentsProvider', function() {
        describe('isExperimentOn method', function() {
            it('should be available on the provider', function() {
                expect(typeof experimentsProvider.isExperimentOn).toBe('function');
            });

            it('should return true if the experiment is on', function() {
                expect(experimentsProvider.isExperimentOn('test.experiment.on')).toBe(true);
            });

            it('should return false if the experiment is off', function() {
                expect(experimentsProvider.isExperimentOn('test.experiment.off')).toBe(false);
            });

            it('should return on if the experiment is control', function() {
                expect(experimentsProvider.isExperimentOn('test.experiment.control')).toBe(false);
            });

            it('should return false if the experiment is undefined', function() {
                expect(experimentsProvider.isExperimentOn('experimentNotFound')).toBe(false);
            });
        });
    });

    describe('experiments service', function() {
        describe('isExperimentOn method', function() {
            it('should reference the same method as the provider', function() {
                expect(experimentsService.isExperimentOn).toBe(experimentsProvider.isExperimentOn);
            });
        });
    });
});
