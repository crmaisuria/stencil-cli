describe('Factory: addressUtils', function() {

  var addressUtils;

  beforeEach(module('ng-common.address.address-utils-factory'));

  beforeEach(inject(function(_addressUtils_) {
    addressUtils = _addressUtils_;
  }));

  describe('addressUtils prettify', function() {
    it ('should transform an address object into a formatted address string', function() {
      var address = addressUtils.prettify({
        first_name: 'John',
        last_name: 'Smith',
        address_1: '123 Fake St',
        address_2: 'Unit 1',
        city: 'Sydney',
        state: 'NSW',
        post_code: '2000',
        country_name: 'Australia'
      }, '\n');
      expect(address).toBe('John Smith\n123 Fake St\nUnit 1\nSydney, NSW 2000\nAustralia');
    });

    it ('should transform an address object that excludes fields', function() {
      var address = addressUtils.prettify({
        first_name: 'Uxío',
        last_name: 'Griogal',
        address_1: '4 Wallace Cottages',
        city: 'Southend',
        country_name: 'Scotland'
      }, '\n');
      expect(address).toBe('Uxío Griogal\n4 Wallace Cottages\nSouthend\nScotland');
    });
  });
});
