angular.module('ng-common.cdn-path', ['ng-common.cdn-path.filter']);
