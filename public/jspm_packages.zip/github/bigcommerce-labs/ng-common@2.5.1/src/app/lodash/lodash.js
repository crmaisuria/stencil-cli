// Necessary for unit and e2e tests
if (! window.lodashModern) { window.lodashModern = window._; }
angular.module('ng-common.lodash', [])
    // This is pulling the global variable lodashModern from the BCApp footer
    // Please see BIG-10912 for more information
    .constant('_', window.lodashModern);
