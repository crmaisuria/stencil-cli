lodashModern.mixin({
    // @param string: the object that is have an uppercased first character
    uppercaseFirst: function(string) {
        return string.charAt(0).toUpperCase() + string.slice(1);
    }
});
