module.exports = {
    run: {
        include: ['run_js_files', 'run_sass_files', 'run_static_files']
    },
    server: {
        include: [
            'server_js_files',
            'server_sass_files',
            'server_css_changes',
            'server_static_files',
            'server_example_files'
        ]
    }
};
