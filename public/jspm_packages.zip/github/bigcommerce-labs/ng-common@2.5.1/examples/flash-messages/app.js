angular.module('ng-common.bc-app', [])
    .constant('BC_APP_CONFIG', {});

angular.module('app', [
    'ng-common'
])
    .controller('AppCtrl', function(flashMessages) {
        var ctrl = this,
            adjectives = [
                'rad',
                'cool',
                'awesome',
                'superb'
            ];

        ctrl.addMessage = addMessage;

        function addMessage() {
            flashMessages.success({
                //Can use template or templateUrl here.
                template: 'Check out this {{ adjective }} <a href="{{ storeUrl }}">store</a>.',
                context: {
                    adjective: adjectives[getRandomInt(0, 4)],
                    storeUrl: 'http://a.mybigcommerce.com/'
                },
                time: ctrl.time || 7e3
            });
        }

        function getRandomInt(min, max) {
            return Math.floor(Math.random() * (max - min)) + min;
        }
    });
