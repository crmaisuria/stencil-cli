var app1 = angular.module('app1', ['ng-common.interapp']);
var app2 = angular.module('app2', ['ng-common.interapp']);

var eventName = 'foo';

app1.controller('App1Ctrl', function($scope, interapp) {
    var Ctrl = this;

    Ctrl.message = '';
    Ctrl.triggerEvent = function() {
        interapp.publish(eventName, {message: Ctrl.message});
        Ctrl.message = '';
    };
});

app2.controller('App2Ctrl', function($scope, $log, interapp) {
    var Ctrl = this;

    Ctrl.receivedMessages = [];

    var eventSubToken = interapp.subscribe(eventName, function(message, data) {
        $scope.$apply(function() {
            Ctrl.receivedMessages.push(data.message);
            $log.log(Ctrl.receivedMessages);
        });
    });

    Ctrl.unsubscribe = function() {
        interapp.unsubscribe(eventSubToken);
    };
});

angular.bootstrap(document.getElementById('app1'), ['app1']);
angular.bootstrap(document.getElementById('app2'), ['app2']);
