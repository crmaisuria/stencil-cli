/* */ 
"format global";
var gulp = require('gulp'),
    ngAnnotate = require('gulp-ng-annotate');

gulp.task('ngAnnotate', function() {
    gulp.src('web/js/app.js')
        .pipe(ngAnnotate())
        .pipe(gulp.dest('.'));
});
