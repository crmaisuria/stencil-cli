/* */ 
"format global";
var Gemini = require('gemini/api'),
    gulp = require('gulp'),
    imagemin = require('gulp-imagemin'),
    config = require('../util/geminiConfig'),
    launchPhantomJS = require('../util/launchPhantomJS'),
    path = require('path'),
    cwd = process.cwd(),
    screenshotsDir = path.join(cwd, config.screenshotsDir),
    testsPath = path.join(cwd, 'gemini', 'tests'),
    reporters = ['flat', 'html'];

function gatherTask(done) {
    var gemini = new Gemini();

    launchPhantomJS(function(err, child) {
        gemini
            .gather([testsPath], { reporters: reporters })
            .then(function handleSuccess() {
                compressScreenshots(done);
            })
            .catch(function handleError(err) {
                done(err);
            })
            .fin(function handleComplete() {
                child.kill();
            });
    });
}

function testTask(done) {
    var gemini = new Gemini();

    launchPhantomJS(function(err, child) {
        gemini
            .test([testsPath], { reporters: reporters })
            .then(function handleSuccess(results) {
                var err;

                if (results.failed) {
                    err = new Error('Gemini reported ' + results.failed + ' error(s).');

                    return done(err);
                }

                done();
            })
            .catch(function handleError(err) {
                done(err);
            })
            .fin(function handleComplete() {
                child.kill();
            });
    });
}

function compressScreenshots(done) {
    gulp.src(path.join(screenshotsDir, '**', '*.png'))
        .pipe(imagemin())
        .pipe(gulp.dest(screenshotsDir))
        .on('end', done)
        .on('error', done);
}

gulp.task('gemini:gather', ['build'], gatherTask);
gulp.task('gemini:gatheronly', gatherTask);

gulp.task('gemini:test', ['build'], testTask);
gulp.task('gemini:testonly', testTask);
