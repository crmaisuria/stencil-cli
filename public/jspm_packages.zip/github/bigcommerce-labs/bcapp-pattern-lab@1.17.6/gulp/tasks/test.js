/* */ 
"format global";
var gulp = require('gulp');

gulp.task('test', [
    'scss-lint',
    'karma:bcappPatternLab',
    'karma:website'
]);
