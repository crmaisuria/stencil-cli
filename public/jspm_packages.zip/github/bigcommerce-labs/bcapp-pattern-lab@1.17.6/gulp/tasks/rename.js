/* */ 
"format global";
var gulp = require('gulp'),
    config = require('../config'),
    rename = require('gulp-rename');

gulp.task('rename-min-js', function() {

    var stream = gulp.src(config.js.build + '/**/*.js')
        .pipe(rename({suffix: '.min'}))
        .pipe(gulp.dest(config.js.build));

    return stream;
});

gulp.task('rename-min-css', function() {

    var stream = gulp.src(config.css.build + '/*.css')
        .pipe(rename({suffix: '.min'}))
        .pipe(gulp.dest(config.css.build));

    return stream;
});

gulp.task('rename-min', ['rename-min-css', 'rename-min-js']);
