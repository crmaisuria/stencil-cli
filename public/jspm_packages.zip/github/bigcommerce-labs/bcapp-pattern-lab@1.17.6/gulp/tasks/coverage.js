/* */ 
"format global";
var gulp = require('gulp'),
    karma = require('karma').server;

function coverage(done) {
    karma.start({
        configFile: __dirname + '/karma.coverage.conf.js',
        singleRun: true
    }, done);
}

gulp.task('coverage', ['build'], coverage);


