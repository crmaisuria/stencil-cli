/* */ 
"format global";
var gulp = require('gulp'),
    flatten = require('gulp-flatten'),
    config = require('../config'),
    handleErrors = require('../util/handleErrors'),
    imagemin = require('gulp-imagemin');

function svgs() {

    var stream = gulp.src(config.icons.src + '/**/*')
        .pipe(flatten())
        .pipe(imagemin())
        .on('error', handleErrors)
        .pipe(gulp.dest(config.icons.build));

    return stream;

}

gulp.task('icons', ['material-design-icons'], svgs);
gulp.task('icons:watch', svgs);
