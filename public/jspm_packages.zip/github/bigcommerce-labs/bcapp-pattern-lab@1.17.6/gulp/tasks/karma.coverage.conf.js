/* */ 
"format global";
var gulpConfig = require('../config'),
    preprocessors = {},
    preprocessorsPath = gulpConfig.js.src + '/bigcommerce/**/!(*spec).js';

preprocessors[preprocessorsPath] = ['coverage'];

module.exports = function(config) {
    config.set({
        'basePath': '../../',
        'files': [
            gulpConfig.js.build + '/vendor.js',
            gulpConfig.js.build + '/bcapp/bcapp-pattern-lab-templates.js',
            gulpConfig.js.src + '/**/*.js'
        ],
        exclude: [
            gulpConfig.js.src + '/**/*.scenario.js'
        ],
        'preprocessors': preprocessors,
        'coverageReporter': {
            'type': 'lcov',
            'dir': 'coverage'
        },
        'frameworks': [
            'jasmine'
        ],
        'plugins': [
            'karma-jasmine',
            'karma-phantomjs-launcher',
            'karma-coverage'
        ],
        'reporters': ['coverage', 'dots'],
        'port': 9018,
        'runnerPort': 9100,
        'singleRun': true,
        'background': false,
        'urlRoot': '/',
        'autoWatch': false,
        'logLevel': 'INFO',
        'browsers': [
            'PhantomJS'
        ]
    });
};
