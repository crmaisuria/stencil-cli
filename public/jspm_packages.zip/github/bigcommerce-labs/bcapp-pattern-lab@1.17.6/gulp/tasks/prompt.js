/* */ 
"format global";
var gulp = require('gulp'),
    colors = require('colors'),
    config = require('../config'),
    handleErrors = require('../util/handleErrors'),
    semver = require('semver'),
    currentVersion = require('../../package.json').version,
    prompt = require('gulp-prompt'),
    gulpif = require('gulp-if'),
    git = require('gulp-git'),
    bump = require('gulp-bump'),
    filter = require('gulp-filter'),
    tagVersion = require('gulp-tag-version'),
    targetVersion;

function promptBump() {

    var stream = gulp.src(config.dest.src)
        .pipe(prompt.prompt([{
            type: 'confirm',
            name: 'sass-lib-version',
            message: 'Have you followed the README around getting the latest version of '.yellow + 'citadel'.red + '? Exit this, do it now!'.yellow
        },
        {
            type: 'list',
            name: 'type',
            message: 'What type of release would you like to do?',
            choices: [
                {
                    value: 'patch',
                    name: 'Patch:  '.yellow + semver.inc(currentVersion, 'patch').yellow +
                        '   Backwards-compatible bug fixes.'
                },
                {
                    value: 'minor',
                    name: 'Minor:  '.yellow + semver.inc(currentVersion, 'minor').yellow +
                        '   Component release or significant update to existing one.'
                },
                {
                    value: 'major',
                    name: 'Major:  '.yellow + semver.inc(currentVersion, 'major').yellow +
                        '   Major UI refresh.'
                },
                {
                    value: 'custom',
                    name: 'Custom: ?.?.?'.yellow +
                        '   Specify version...'
                }
            ]
        },
        {
            type: 'input',
            name: 'custom-version',
            message: 'What specific version would you like',
            when: function(answers) {
                return answers['type'] === 'custom';
            },
            validate: function(value) {
                var valid = semver.valid(value) && true;
                return valid || 'Must be a valid semver, such as 1.2.3';
            }
        }], function(res) {

            targetVersion = (res.type !== 'custom') ? semver.inc(currentVersion, res.type) : res['custom-version'];

            gulp.src(['./package.json', './bower.json'])
                // bump the version number in those files
                .pipe(bump({version: targetVersion}))
                // save it back to filesystem
                .pipe(gulp.dest('./'));

        }))
        .on('error', handleErrors);

    return stream;

}

function promptCommit() {

    var stream = gulp.src(config.dest.src)
        .pipe(prompt.prompt([
        {
            type: 'confirm',
            name: 'commit',
            message: 'Do you want to commit the ./dist, ./public, bower.json, and package.json files?'
        },
        {
            name: 'tag',
            type: 'confirm',
            message: 'Do you want to tag this release?',
            when: function(answers) {
                return answers['commit'];
            }
        }], function(res) {

            gulp.src(['./dist', './public', './package.json', './bower.json'])
                // Stage files
                .pipe(gulpif(res.commit, git.add()))
                // commit the changed version number
                .pipe(gulpif(res.commit, git.commit('Releasing ' + currentVersion)))
                // read only one file to get the version number
                .pipe(filter('package.json'))
                // **tag it in the repository**
                .pipe(gulpif(res.tag, tagVersion()));

        }))
        .on('error', handleErrors);

    return stream;

}

gulp.task('prompt:bump', promptBump);
gulp.task('prompt:commit', promptCommit);
