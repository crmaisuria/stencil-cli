/* */ 
"format global";
var gulp = require('gulp'),
    concat = require('gulp-concat'),
    config = require('../config'),
    handleErrors = require('../util/handleErrors'),
    ngAnnotate = require('gulp-ng-annotate'),
    uglify = require('gulp-uglify'),
    bcappScripts = {
        source: config.js.build + '/bcapp/*.js',
        dest: config.js.build + '/bcapp/',
        name: 'bcapp-pattern-lab.js'
    },
    websiteScripts = {
        source: config.js.build + '/website/*.js',
        dest: config.js.build + '/website/',
        name: 'website.js'
    },
    vendorScripts = {
        source: config.js.build + '/vendor.js',
        dest: config.js.build + '/',
        name: 'vendor.js'
    };

function uglifyPatternlab(source, name, dest) {

    var stream = gulp.src(source)
        .pipe(concat(name))
        .pipe(ngAnnotate())
        .pipe(uglify())
        .on('error', handleErrors)
        .pipe(gulp.dest(dest));

    return stream;

}

gulp.task('uglify', [
    'uglify:website'
], uglifyPatternlab.bind(null, bcappScripts.source, bcappScripts.name, bcappScripts.dest));

gulp.task('uglify:website', [
    'uglify:vendor'
], uglifyPatternlab.bind(null, websiteScripts.source, websiteScripts.name, websiteScripts.dest));

gulp.task('uglify:vendor',  uglifyPatternlab.bind(null, vendorScripts.source, vendorScripts.name, vendorScripts.dest));
