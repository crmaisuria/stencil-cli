/* */ 
describe('Color picker palette directive', function() {
    var $compile,
        $rootScope,
        scope,
        element,
        paletteListElement,
        mockPalette = [
            '#00ABC9',
            '#E5F6F9',
            '#95DB89',
            '#FFB800'
        ];

    beforeEach(module('bcapp-pattern-lab-templates'));
    beforeEach(module('bcapp-pattern-lab.color-picker-palette.directive'));

    beforeEach(inject(function ($injector) {
        $compile = $injector.get('$compile');
        $rootScope = $injector.get('$rootScope');
    }));

    function compileDirective(scope) {
        var tpl = angular.element(
            '<color-picker-palette colors="mockPalette" set-new-color="setNewColorMock" create-new-palette-color="createNewColorMock">' +
            '</color-picker-palette>'
        );

        scope = scope || $rootScope.$new();

        element = $compile(tpl)(scope);

        scope.$digest();

        paletteListElement = element.find('ul');

        return scope;
    }

    // before each test, create a new fresh scope
    beforeEach(inject(function($rootScope) {
        scope = $rootScope.$new();
        scope.mockPalette = mockPalette;
        scope.setNewColorMock = setNewColorMock;
        scope.createNewColorMock = createNewColorMock;

        spyOn(scope, 'setNewColorMock');
        spyOn(scope, 'createNewColorMock');

        function setNewColorMock(color) {
            return color;
        }

        function createNewColorMock() {}

    }));

    beforeEach(function() {
        compileDirective(scope);
    });

    describe('color-picker-palette element' , function() {
        it('should include the standard class', function() {
            expect(element.hasClass('colorPicker-palette')).toBe(true);
        });
    });

    describe('palette list', function() {
        var numberOfListItems;

        it('should display the colours of the palette', function() {
            numberOfListItems = element.find('li').length;
            // Add 1 to the number of colours to accommodate for the add button
            expect(numberOfListItems).toBe(mockPalette.length + 1);
        });
    });

    describe('color selection', function() {
        it('should call the callback function with color value', function() {
            var el = element.find('a')[0];

            angular.element(el).triggerHandler('click');

            expect(scope.setNewColorMock).toHaveBeenCalledWith(jasmine.any(Object), '#00ABC9');
        });
    });

    describe('new palette colour creation', function() {
        it('should call the callback function', function() {
            var el = element.find('a')[4];

            angular.element(el).triggerHandler('click');

            expect(scope.createNewColorMock).toHaveBeenCalled();
        });
    });

});
