/* */ 
describe('form directive', function() {
    var $compile,
        $rootScope,
        element;

    beforeEach(module('bcapp-pattern-lab-templates'));
    beforeEach(module('bcapp-pattern-lab.form'));

    beforeEach(inject(function ($injector) {
        $compile = $injector.get('$compile');
        $rootScope = $injector.get('$rootScope');
    }));

    function compileDirective(scope) {
        var tpl = angular.element(
            '<form disable-auto-focus="{{ disableAutoFocus }}" ng-submit="submit()">' +
                '<input ng-model="input" required />' +
                '<select ng-model="select" required>' +
                    '<option value="test">Test</option>' +
                '</select>' +
            '</form>'
        );


        scope = scope || $rootScope.$new();
        element = $compile(tpl)(scope);

        scope.$digest();

        return scope;
    }

    describe('form element', function() {
        it('should include the standard form class and novalidate attribute', function() {
            compileDirective();

            expect(element.hasClass('form')).toBe(true);
            expect(element.attr('novalidate')).not.toBe(undefined);
        });
    });

    describe('submit', function() {
        beforeEach(function() {
            compileDirective();
        });

        it('should autofocus on the first invalid input, if there is one', function() {
            angular.element(document.body).append(element);

            element.triggerHandler('submit');

            expect(element.find('input')[0]).toBe(document.activeElement);

            element.remove();
        });

        it('should not autofocus if the option is explicitly disabled', function() {
            var scope;

            scope = $rootScope.$new();
            scope.disableAutoFocus = 'true';
            compileDirective(scope);

            angular.element(document.body).append(element);

            element.triggerHandler('submit');

            expect(element.find('input')[0]).not.toBe(document.activeElement);
        });

        it('should autoselect text in the first invalid input, if supported', function() {
            var input = element.find('input')[0];

            element.triggerHandler('submit');

            expect(input.selectionStart === 0).toBe(true);
            expect(input.selectionEnd === input.value.length).toBe(true);
        });

        afterEach(function() {
            element.remove();
        });
    });
});
