/* */ 
angular.module('bcapp-pattern-lab.bc-dropdown.controller', [])
    .controller('BcDropdownController', function bcDropdownController($scope, $rootScope) {
        const ctrl = this;
        let isOpen = false;
        let uniqueId;

        ctrl.closeDropdown = closeDropdown;
        ctrl.getIsOpen = getIsOpen;
        ctrl.getUniqueId = getUniqueId;
        ctrl.setIsOpen = setIsOpen;
        ctrl.toggleIsOpen = toggleIsOpen;

        // listen for other dropdowns being opened in the app.
        $scope.$on('bcDropdownToggle', (event, triggeringID) => {
            // if I'm open and not the dropdown being triggered, then I should close
            if (isOpen && triggeringID !== uniqueId) {
                ctrl.closeDropdown();
            }
        });

        function closeDropdown() {
            ctrl.setIsOpen(false);
            $scope.$broadcast('toggleThisDropdown');
        }

        function getIsOpen() {
            return isOpen;
        }

        function getUniqueId() {
            if (!uniqueId) {
                uniqueId = _.uniqueId('bc-dropdown-');
            }
            return uniqueId;
        }

        function setIsOpen(val) {
            isOpen = val;
        }

        function toggleIsOpen() {
            isOpen = !isOpen;
            // tell child directives a toggle in open status has occurred
            $scope.$broadcast('toggleThisDropdown');
            // tell application that a dropdown has been opened so others can close
            $rootScope.$broadcast('bcDropdownToggle', uniqueId);
        }
    });
