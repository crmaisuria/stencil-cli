/* */ 
angular.module('bcapp-pattern-lab.color-picker.directive', [
    'bcapp-pattern-lab.color-picker.controller',
    'bcapp-pattern-lab.html5Mode',
])

    .directive('colorPicker', function colorPickerDirective($location, html5Mode) {
        return {
            bindToController: true,
            controller: 'ColorPickerCtrl',
            controllerAs: 'colorPickerCtrl',
            require: ['colorPicker', '^ngModel'],
            restrict: 'E',
            scope: {
                palette: '=',
            },
            templateUrl: 'src/js/bigcommerce/color-picker/color-picker.tpl.html',

            compile: function colorPickerDirectiveCompile(tElement) {
                tElement.addClass('colorPicker');

                return function colorPickerDirectiveLink($scope, element, attrs, ctrls) {
                    const ctrl = ctrls[0];
                    const ngModelCtrl = ctrls[1];

                    ctrl.setModelCtrl(ngModelCtrl);
                    ctrl.createColorPicker();

                    // Apps that have a <base> tag require to have absolute paths
                    // when using svg url references
                    if (html5Mode.enabled) {
                        _.each(element[0].querySelectorAll('[fill]'), function(el) {
                            const betweenParenthesis = /\(([^)]+)\)/;
                            const elem = angular.element(el);
                            const currentFill = elem.attr('fill');

                            if (_.contains(currentFill, 'url(#')) {
                                const newFill = betweenParenthesis.exec(currentFill)[1];

                                elem.attr('fill', 'url(' + $location.absUrl() + newFill + ')');
                            }
                        });
                    }

                    $scope.$watch(getModelValue, function modelWatch(newVal) {
                        if (newVal) {
                            ctrl.cp.setHex(newVal);
                        }
                    });

                    function getModelValue() {
                        return ctrl.ngModelCtrl.$modelValue;
                    }
                };
            }
        };
    });
