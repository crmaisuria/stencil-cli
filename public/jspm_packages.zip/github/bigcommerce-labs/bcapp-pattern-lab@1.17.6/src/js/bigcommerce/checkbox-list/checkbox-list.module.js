/* */ 
angular.module('bcapp-pattern-lab.checkbox-list', [
    'bcapp-pattern-lab.checkbox-list.directive'
]);
