/* */ 
angular.module('bcapp-pattern-lab.bc-pagination', [
    'bcapp-pattern-lab.bc-pagination.directive'
]);
