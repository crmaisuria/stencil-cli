/* */ 
angular.module('bcapp-pattern-lab.bc-server-table.controller', [
    'bcapp-pattern-lab.bc-server-table.service'
])

    .controller('BcServerTableCtrl', function BcServerTableCtrl($attrs, $log, $parse, $scope, BcServerTable) {
        var ctrl = this,
            bcServerTablePrototype = BcServerTable.prototype;

        // Call the BcServerTable constructor on the controller
        // in order to set all the controller properties directly.
        // This is here for backwards compatability purposes.
        BcServerTable.call(ctrl, null, ($parse($attrs.tableConfig)($scope)));

        // controller functions
        ctrl.createParamsObject = bcServerTablePrototype.createParamsObject;
        ctrl.fetchResource = bcServerTablePrototype.fetchResource;
        ctrl.getSelectedRows = bcServerTablePrototype.getSelectedRows;
        ctrl.init = bcServerTablePrototype.init;
        ctrl.isRowSelected = bcServerTablePrototype.isRowSelected;
        ctrl.loadStateParams = bcServerTablePrototype.loadStateParams;
        ctrl.selectAllRows = bcServerTablePrototype.selectAllRows;
        ctrl.setPaginationValues = bcServerTablePrototype.setPaginationValues;
        ctrl.setRows = bcServerTablePrototype.setRows;
        ctrl.setSortingValues = bcServerTablePrototype.setSortingValues;
        ctrl.updatePage = _.bind(bcServerTablePrototype.updatePage, ctrl);
        ctrl.updateSort = bcServerTablePrototype.updateSort;
        ctrl.updateTable = bcServerTablePrototype.updateTable;
        ctrl.validateResource = bcServerTablePrototype.validateResource;

        init();

        function init() {
            var resourceCallback;

            resourceCallback = $parse($attrs.resourceCallback)($scope);
            if (!_.isFunction(resourceCallback)) {
                $log.error('bc-server-table directive: resource-callback must be a function.');
                return;
            }
            ctrl.resourceCallback = resourceCallback;

            ctrl.init();
        }
    });
