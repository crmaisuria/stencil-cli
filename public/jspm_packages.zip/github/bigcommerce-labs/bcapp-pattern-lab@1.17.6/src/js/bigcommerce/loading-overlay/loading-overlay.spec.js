/* */ 
describe('loading-overlay directive', function() {
    var $compile,
        $rootScope,
        $scope,
        element,
        ctrl;

    beforeEach(module('bcapp-pattern-lab-templates'));
    beforeEach(module('bcapp-pattern-lab.loading-overlay'));

    beforeEach(inject(function($injector) {
        $compile = $injector.get('$compile');
        $rootScope = $injector.get('$rootScope');
        $scope = $rootScope.$new();
    }));

    function compileDirective(scope) {
        var tpl = angular.element('<div loading-overlay="loading" use-ui-router="watchStateChanges">Hello World</div>');

        element = $compile(tpl)(scope);
        scope.$digest();

        ctrl = element.controller('loadingOverlay');
    }

    describe('loading toggle', function() {
        it('should update the controller when the provided scope variable changes', function() {
            $scope.loading = false;
            compileDirective($scope);

            expect(ctrl.loading).toBe(false);

            $scope.loading = true;
            $scope.$digest();

            expect(ctrl.loading).toBe(true);
        });
    });

    describe('use-ui-router attribute', function() {
        it('should register listeners when truthy', function() {
            spyOn($rootScope, '$on');

            $scope.loading = false;
            $scope.watchStateChanges = true;
            compileDirective($scope);

            expect($rootScope.$on.calls.argsFor(0)[0]).toBe('$stateChangeStart');
            expect($rootScope.$on.calls.argsFor(1)[0]).toBe('$stateChangeSuccess');
            expect($rootScope.$on.calls.argsFor(2)[0]).toBe('$stateChangeError');
        });
    });
});
