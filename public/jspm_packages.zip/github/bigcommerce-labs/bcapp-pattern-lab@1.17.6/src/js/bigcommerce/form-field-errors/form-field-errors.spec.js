/* */ 
describe('form-field-errors directive', function() {
    var $compile,
        $rootScope,
        element,
        formCtrl,
        formFieldErrorsElement;

    beforeEach(module('bcapp-pattern-lab-templates'));
    beforeEach(module('bcapp-pattern-lab.form-field'));
    beforeEach(module('bcapp-pattern-lab.form-field-errors'));

    beforeEach(inject(function ($injector) {
        $compile = $injector.get('$compile');
        $rootScope = $injector.get('$rootScope');
    }));

    function compileDirective(scope) {
        var tpl = angular.element(
            '<form>' +
                '<form-field property="username">' +
                    '<input name="username" ng-model="username" required />' +
                    '<form-field-errors></form-field-errors>' +
                '</form-field>' +
                '<button type="submit">Submit</button>' +
            '</form>'
        );


        scope = scope || $rootScope.$new();
        element = $compile(tpl)(scope);

        scope.$digest();

        formCtrl = element.controller('form');
        formFieldErrorsElement = element.find('ul');

        return scope;
    }

    describe('element', function() {
        beforeEach(function() {
            compileDirective();
        });

        it('should include the standard class', function() {
            expect(formFieldErrorsElement.hasClass('form-field-errors')).toBe(true);
        });

        it('should add all required attributes', function() {
            expect(formFieldErrorsElement.attr('ng-messages')).toBeTruthy();
        });
    });

    describe('scope', function() {
        it('should have all the required properties set', function() {
            var scope;

            compileDirective();

            scope = formFieldErrorsElement.scope();

            expect(scope.formCtrl).toEqual(formCtrl);
            expect(scope.property).toEqual('username');
            expect(scope.propertyField).toEqual(formCtrl[scope.property]);
        });
    });
});
