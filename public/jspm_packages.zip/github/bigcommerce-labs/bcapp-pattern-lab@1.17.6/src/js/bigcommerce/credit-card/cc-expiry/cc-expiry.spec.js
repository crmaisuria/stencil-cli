/* */ 
describe('Credit card expiry directive', function() {
    var ccDataDefault = {
            ccExpiry: {
                month: '',
                year: ''
            }
        },
        dateFixtures = [
            {
                formatted: '08 / 25',
                model: { month: '08', year: '2025' },
                raw: '0825',
                valid: true
            },
            {
                formatted: '07 / 15',
                model: undefined,
                raw: '0715',
                valid: false
            },
            {
                formatted: '08 / 1',
                model: undefined,
                raw: '081',
                valid: false
            },
            {
                formatted: '',
                model: undefined,
                raw: '',
                valid: false
            },
        ],
        directiveHtml = '<input autocomplete="cc-exp" cc-expiry class="form-input" id="ccExpiry" name="ccExpiry" ng-model="ccData.ccExpiry" ng-required="true" placeholder="MM / YY" type="text"/>',
        $compile,
        scope,
        element;

    beforeEach(module('bcapp-pattern-lab.credit-card.cc-expiry.directive'));

    beforeEach(inject(function($injector) {
        $compile = $injector.get('$compile');
        scope = $injector.get('$rootScope').$new();
    }));

    beforeEach(function() {
        scope.ccData = _.clone(ccDataDefault);
    });

    function compileDirective(scope, tpl) {
        var element = angular.element(tpl || directiveHtml),
            compiledElement = $compile(element)(scope);

        scope.$digest();

        return compiledElement;
    }

    function setInput(value) {
        element.val(value);
        element.triggerHandler('input');
        scope.$digest();
    }

    function resetInput() {
        setInput('');
    }

    function deleteChar(beforeValue) {
        var afterValue = beforeValue.length ? beforeValue.slice(0, beforeValue.length - 1) : '';

        setInput(afterValue);
    }

    describe('the compiled html', function() {
        beforeEach(function() {
            element = compileDirective(scope);
        });


        it('should add a numeric pattern', function() {
            expect(element.attr('pattern')).toBe('[0-9]*');
        });

        it('should add an autocomplete attribute', function() {
            expect(element.attr('autocomplete')).toBe('cc-exp');
        });
    });

    describe('input value based on initial ngModel value', function() {
        it('should have an empty input value for an initial empty object as ngModel value', function() {
            element = compileDirective(scope);
            expect(element.val()).toEqual('');
        });

        it('should have a formatted input value for a initial valid date ngModel with 4 digit year', function() {
            var date = _.findWhere(dateFixtures, { valid: true });

            scope.ccData.ccExpiry = date.model;

            element = compileDirective(scope);
            expect(element.val()).toEqual(date.formatted);
        });

        it('should have a formatted input value for a initial valid date ngModel with 2 digit year', function() {
            scope.ccData.ccExpiry = {
                month: '8',
                year: '25'
            };

            element = compileDirective(scope);
            expect(element.val()).toEqual('08 / 25');
        });
    });

    describe('when typing', function() {
        beforeEach(function() {
            element = compileDirective(scope);
        });

        it('the date string should be formatted', function() {
            dateFixtures.forEach(function(date) {
                setInput(date.raw);

                expect(element.val()).toEqual(date.formatted);
                expect(scope.ccData.ccExpiry).toEqual(date.model);

                resetInput(element);
            });
        });

        it('should handle deleting characters', function() {
            setInput('0825');
            expect(element.val()).toEqual('08 / 25');
            expect(scope.ccData.ccExpiry).toEqual({ month: '08', year: '2025'});

            deleteChar(element.val());
            expect(element.val()).toEqual('08 / 2');
            expect(scope.ccData.ccExpiry).toEqual(undefined);

            deleteChar(element.val());
            expect(element.val()).toEqual('08');
            expect(scope.ccData.ccExpiry).toEqual(undefined);

            deleteChar(element.val());
            expect(element.val()).toEqual('0');
            expect(scope.ccData.ccExpiry).toEqual(undefined);

            deleteChar(element.val());
            expect(element.val()).toEqual('');
            expect(scope.ccData.ccExpiry).toEqual(undefined);
         });
    });

    describe('invalid states', function() {
        beforeEach(function() {
            element = compileDirective(scope);
        });

        it('should have `ng-valid` for valid dates', function() {
            var date = _.findWhere(dateFixtures, { valid: true });

            setInput(date.raw);
            expect(element.hasClass('ng-valid')).toBe(true);
        });

        it('should have `ng-invalid` for the invalid', function() {
            var dates = _.filter(dateFixtures, { valid: false });

            dates.forEach(function(date) {
                setInput(date.raw);

                expect(element.hasClass('ng-invalid')).toBe(true);

                resetInput(element);
            });
        });

        it('should have `validFutreDate` error for a past date', function() {
            var date = _.findWhere(dateFixtures, { raw: '0715' });

            setInput(date.raw);
            expect(element.hasClass('ng-invalid-valid-future-date')).toBe(true);
        });

        it('should not have `validFutreDate` error for a date of current month', function() {
            var currDateRaw = getCurrDateRaw();

            setInput(currDateRaw);
            expect(element.hasClass('ng-invalid-valid-future-date')).toBe(false);
        });

        function getCurrDateRaw() {
            var date = new Date(),
                month = (date.getMonth() + 1).toString(),
                monthStr = month.length > 1 ? month : '0' + month,
                year = date.getFullYear().toString().slice(-2);

            return monthStr + year;
        }
    });
});
