/* */ 
describe('bcPagination', function() {
    beforeEach(function() {
        browser.get('/js-components.html#/components/bc-pagination');
    });

    describe('Page Numbers', function() {
        it('should go to the next page when the Next button is clicked', function() {
            $$('.pagination > li:nth-child(2) > a').first().click();
            expect($('.currentPage').getText()).toBe('2');

            $$('.firstPagination .pagination-item--arrow').last().click();
            expect($('.currentPage').getText()).toBe('3');
        });

        it('should change the current page to the number clicked', function() {
            $$('.pagination-list > li:nth-child(4) > a').first().click();

            expect($('.currentPage').getText()).toBe('3');
        });

        it('should go to the previous page when the Previous button is clicked', function() {
            $$('.pagination-list > li:nth-child(4) > a').first().click();

            $$('.pagination > li:nth-child(1) > a').first().click();

            expect($('.currentPage').getText()).toBe('2');
            $$('.firstPagination .pagination-item--arrow').first().click();

            expect($('.currentPage').getText()).toBe('1');
        });
    });

    describe('Limits Dropdown', function() {

        it('should change the limits per page when clicking an option', function() {
            expect(element(by.model('itemsPerPage')).getAttribute('value')).toBe('10');

            $('.firstPagination .pagination-limits').click();
            $$('.firstPagination li > a').last().click();

            expect(element(by.model('itemsPerPage')).getAttribute('value')).toBe('100');
        });
    });
});
