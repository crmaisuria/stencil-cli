/* globals rome */
angular.module('bcapp-pattern-lab.bc-datepicker.directive', [
    'bcapp-pattern-lab.bc-datepicker.constants'
])
    .directive('bcDatepicker', function bcDatepickerDirective(BC_DATEPICKER_DEFAULTS) {
        return {
            restrict: 'A',
            require: 'ngModel',
            scope: {
                options: '=?'
            },

            link: function datepickerLinkFunction(scope, element, attrs, ngModel) {
                if (scope.options === undefined) {
                    scope.options = {};
                }

                // Add defaults to the options object
                _.defaults(scope.options, BC_DATEPICKER_DEFAULTS);

                // Create a new rome (calendar) instance
                scope.calendar = rome(element[0], scope.options);

                // On 'data' event set ngModel to the passed value
                scope.calendar.on('data', function onData(value) {
                    ngModel.$setViewValue(value);
                    scope.$apply();
                });

                scope.calendar.on('ready', function onReady(options) {
                    if (attrs.placeholder === undefined) {
                        attrs.$set('placeholder', options.inputFormat);
                    }
                });

                // Removing calendar event listeners
                element.on('$destroy', function onDestroy() {
                    scope.calendar.destroy();
                });
            }
        };
    });
