/* */ 
angular.module('bcapp-pattern-lab.bc-server-table.service', [
    'ui.router'
])
    .factory('BcServerTable', function bcServerTable($log, $q, $state, $stateParams) {
        var defaultTableConfig = {
            filters: [],
            queryKeys: {
                page: 'page',
                limit: 'limit',
                sortBy: 'sort-by',
                sortDir: 'sort-order'
            },
            rowIdKey: 'id',
            sortDirValues: {
                asc: 'asc',
                desc: 'desc'
            }
        };

        function ServerTable(tableId, tableConfig) {
            this.allSelected = false;
            this.filters = {};
            this.id = tableId;
            this.pagination = {
                page: null,
                limit: null,
                total: null
            };
            this.pendingRequest = false;
            this.resourceCallback = angular.noop;
            this.rows = [];
            this.selectedRows = {};
            this.sortBy = '';
            this.sortDir = '';
            
            this.tableConfig = _.isObject(tableConfig) ? tableConfig : {};
            this.tableConfig = _.defaults(this.tableConfig, defaultTableConfig);
        }

        ServerTable.prototype = {
            createParamsObject: createParamsObject,
            fetchResource: fetchResource,
            getSelectedRows: getSelectedRows,
            init: init,
            isRowSelected: isRowSelected,
            loadStateParams: loadStateParams,
            selectAllRows: selectAllRows,
            setPaginationValues: setPaginationValues,
            setRows: setRows,
            setSortingValues: setSortingValues,
            updatePage: updatePage,
            updateSort: updateSort,
            updateTable: updateTable,
            validateResource: validateResource
        };

        function createParamsObject() {
            var params = {},
                queryKeys = this.tableConfig.queryKeys,
                queryParamMap = [{
                        queryKey: queryKeys.page,
                        value: this.pagination.page
                    }, {
                        queryKey: queryKeys.limit,
                        value: this.pagination.limit
                    }, {
                        queryKey: queryKeys.sortBy,
                        value: this.sortBy
                    }, {
                        queryKey: queryKeys.sortDir,
                        value: this.sortDir
                    }];

            _.each(queryParamMap, function queryParamMapEach(param) {
                if (param.queryKey !== undefined) {
                    params[param.queryKey] = param.value;
                }
            });

            _.extend(params, this.filters);

            return params;
        }

        function fetchResource() {
            var _this = this;

            this.pendingRequest = true;
            return this.resourceCallback(this.createParamsObject())
                .then(function resourceCallbackThen(resource) {
                    if (_this.validateResource(resource)) {
                        _this.setRows(resource.rows);
                        _this.setPaginationValues(resource.pagination);
                    }

                    return _this;
                })
                .catch(function resourceCallbackCatch(error) {
                    $log.error('bc-server-table directive: failed to fetch resource');

                    return $q.reject(error);
                })
                .finally(function resourceCallbackFinally() {
                    _this.pendingRequest = false;
                });
        }

        function getSelectedRows() {
            var _this = this;

            return _.filter(this.rows, function getSelectedRowsFilter(row) {
                return _this.isRowSelected(row);
            });
        }

        function init(config) {
            if (!_.isObject(config)) {
                config = {};
            }

            if (_.isFunction(config.resourceCallback)) {
                this.resourceCallback = config.resourceCallback;
            }

            return this
                .loadStateParams(config.stateParams)
                .fetchResource();
        }

        function isRowSelected(row) {
            return this.selectedRows[row[this.tableConfig.rowIdKey]];
        }

        function loadStateParams(stateParams) {
            var queryKeys = this.tableConfig.queryKeys,
                _this = this;

            stateParams = stateParams || $stateParams;

            this.setPaginationValues({
                page: stateParams[queryKeys.page],
                limit: stateParams[queryKeys.limit]
            });

            this.setSortingValues(stateParams[queryKeys.sortBy], stateParams[queryKeys.sortDir]);

            // set filters from query params
            _.each(this.tableConfig.filters, function setFiltersEach(value) {
                _this.filters[value] = stateParams[value];
            });

            return this;
        }

        function selectAllRows() {
            var _this = this;

            this.allSelected = !this.allSelected;
            _.each(this.selectedRows, function selectAllRowsEach(value, key) {
                _this.selectedRows[key] = _this.allSelected;
            });

            return this;
        }

        function setPaginationValues(pagination) {
            this.pagination = this.pagination || {};
            _.extend(this.pagination, pagination);

            return this;
        }

        function setRows(rows) {
            var _this = this;

            this.rows = rows;
            this.selectedRows = _.reduce(rows, function initializeSelectedRowsObject(accum, row) {
                accum[row[_this.tableConfig.rowIdKey]] = false;
                return accum;
            }, {});

            return this;
        }

        function setSortingValues(sortBy, sortDir) {
            this.sortBy = sortBy || this.sortBy;
            this.sortDir = sortDir || this.sortDir;

            return this;
        }

        function updatePage(page, limit, total) {
            return this
                .setPaginationValues(page, limit, total)
                .updateTable();
        }

        function updateSort(sortBy, sortDir) {
            return this
                .setSortingValues(sortBy, sortDir)
                .setPaginationValues({
                    page: 1
                })
                .updateTable();
        }

        function updateTable() {
            if (!this.pendingRequest) {
                $state.go($state.current.name, this.createParamsObject());
            }

            return this;
        }

        function validateResource(resource) {
            if (!_.isObject(resource)) {
                $log.error('bc-server-table directive: Resource callback must return an object');
                return false;
            }

            if (!_.isArray(resource.rows)) {
                $log.error('bc-server-table directive: returned object must contain a rows property that is an array.');
                return false;
            }

            if (!_.isObject(resource.pagination)) {
                $log.error('bc-server-table directive: returned object must contain a pagination property that is an object.');
                return false;
            }

            return true;
        }

        return ServerTable;
    });
