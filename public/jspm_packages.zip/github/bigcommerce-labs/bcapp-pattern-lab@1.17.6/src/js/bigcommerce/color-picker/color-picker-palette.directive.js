/* */ 
angular.module('bcapp-pattern-lab.color-picker-palette.directive', [
    'bcapp-pattern-lab.color-picker-palette.controller'
])

    .directive('colorPickerPalette', function colorPickerPaletteDirective() {
        return {
            bindToController: true,
            controller: 'ColorPickerPaletteCtrl',
            controllerAs: 'colorPickerPaletteCtrl',
            restrict: 'E',
            scope: {
                colors: '=',
                createNewPaletteColor: '=',
                setNewColor: '=',
            },
            templateUrl: 'src/js/bigcommerce/color-picker/color-picker-palette.tpl.html',
            compile: function colorPickerPaletteDirectiveCompile(tElement) {
                tElement.addClass('colorPicker-palette');
            }
        };
    });
