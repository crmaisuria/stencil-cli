/* */ 
angular.module('bcapp-pattern-lab.form-field', [
    'bcapp-pattern-lab.form-field.directive',
    'bcapp-pattern-lab.form-field-error',
    'bcapp-pattern-lab.form-field-errors'
]);
