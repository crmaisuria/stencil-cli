/* */ 
angular.module('bcapp-pattern-lab.loading-overlay.directive', [
    'bcapp-pattern-lab.loading-overlay.controller'
])
    .directive('loadingOverlay', function loadingOverlay($compile) {
        return {
            bindToController: true,
            controller: 'LoadingOverlayCtrl as loadingOverlayCtrl',
            restrict: 'A',
            scope: {
                debounce: '=?',
                loading: '=?loadingOverlay',
                useUiRouter: '=?'
            },
            compile: function loadingOverlayCompile(element) {
                element.addClass('loadingOverlay-container');

                return function loadingOverlayLink(scope, element) {
                    const overlay = $compile('<div class="loadingOverlay" ng-if="loadingOverlayCtrl.loading"></div>')(scope);
                    element.append(overlay);
                };
            }
        };
    });
