/* */ 
angular.module('bcapp-pattern-lab.form-input-color.controller', [])

    .controller('FormInputColorCtrl', function($element, $rootScope, $scope) {
        const ctrl = this;
        const hexColorRegex = /^#(([0-9a-fA-F]{2}){3}|([0-9a-fA-F]){3})$/;

        let isVisible = false;

        ctrl.blurEventHandler = blurEventHandler;
        ctrl.focusEventHandler = focusEventHandler;
        ctrl.hidePicker = hidePicker;
        ctrl.isPickerVisible = isPickerVisible;
        ctrl.onChange = onChange;
        ctrl.setModelCtrl = setModelCtrl;
        ctrl.showPicker = showPicker;
        ctrl.uniqueId = getUniqueID('formInputColor-');

        $scope.$on('bcColorPickerOpened', (event, triggeringElement) => {
            if ($element === triggeringElement) {
                return;
            }

            ctrl.hidePicker();
        });

        function blurEventHandler($event) {
            if ($element[0].contains($event.relatedTarget)) {
                return;
            }

            ctrl.hidePicker();
        }

        function focusEventHandler($event) {
            $event.preventDefault();
            ctrl.showPicker();
        }

        function getUniqueID(idPrefix) {
            return _.uniqueId(idPrefix);
        }

        function hidePicker() {
            if (ctrl.isPickerVisible()) {
                ctrl.isPickerVisible(false);
            }
        }

        function isPickerVisible(isVisibleToSet) {
            if (isVisibleToSet !== undefined) {
                isVisible = isVisibleToSet;
            }

            return isVisible;
        }

        function onChange() {
            if (hexColorRegex.test(ctrl.color)) {
                ctrl.lastValidColor = ctrl.color;
                ctrl.ngModelCtrl.$setViewValue(ctrl.color);
            }
        }

        function render() {
            ctrl.color = ctrl.ngModelCtrl.$viewValue;
            ctrl.lastValidColor = ctrl.color;
        }

        function setModelCtrl(ngModelCtrl) {
            ctrl.ngModelCtrl = ngModelCtrl;
            ctrl.ngModelCtrl.$render = render;
        }

        function showPicker() {
            $rootScope.$broadcast('bcColorPickerOpened', $element);
            ctrl.isPickerVisible(true);
        }
    });
