/* */ 
describe('loading-overlay directive', function() {
    beforeEach(function() {
        browser.get('/js-components.html#/components/loaders');
    });

    it('should add container class to the element directive is attached to', function() {
        expect(element(by.css('#loadingOverlay-example1 [loading-overlay]'))).toHaveClass('loadingOverlay-container');
    });

    it('should not show loading overlay element when not loading', function() {
        expect(element(by.css('#loadingOverlay-example1 [loading-overlay] .loadingOverlay')).isPresent()).toBe(false);
    });

    it('should show the loading overlay element when loading', function() {
        element(by.css('.e2e-toggleLoading')).click();
        expect(element(by.css('#loadingOverlay-example1 [loading-overlay] .loadingOverlay')).isPresent()).toBe(true);
    });

    it('should hide the content when a state transition starts', function() {
        var ignoreSyncValue = browser.ignoreSynchronization;

        browser.ignoreSynchronization = true;

        element(by.css('.e2e-triggerStateChange')).click();

        browser.wait(function() {
            return element(by.css('#loadingOverlay-example2 [loading-overlay] .loadingOverlay')).isPresent();
        }, 3000);

        expect(element(by.css('#loadingOverlay-example2 [loading-overlay] .loadingOverlay')).isPresent()).toBe(true);

        browser.controlFlow().execute(function() {
            browser.ignoreSynchronization = ignoreSyncValue;
        });
    });
});
