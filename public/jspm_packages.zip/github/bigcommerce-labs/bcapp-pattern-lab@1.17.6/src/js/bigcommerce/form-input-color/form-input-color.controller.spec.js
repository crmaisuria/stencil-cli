/* */ 
describe('Form Input Color controller', function() {
    var $controller,
        controller,
        mockEvent;

    function createController() {
        return $controller('FormInputColorCtrl');
    }

    beforeEach(function() {
        module('bcapp-pattern-lab.form-input-color.controller');
    });

    beforeEach(inject(function($injector) {
        $controller = $injector.get('$controller');
    }));

    beforeEach(function() {
        controller = createController();
        mockEvent = { preventDefault: _.noop };
    });

    describe('isPickerVisible method', function() {
        // it('should return false as initial state of Visibility', function() {
            // expect(controller.isPickerVisible()).toBe(false);
        // });
    });

    describe('hidePicker method', function() {
    });

    describe('showPicker method', function() {
    });

});
