/* */ 
"format global";
describe('bc-server-table', function() {
    var URI = require('URIjs');

    function getQueryParams(url) {
        var uri = new URI(url);
        var fragment = new URI(uri.fragment());
        return URI.parseQuery(fragment.query());
    }

    beforeEach(function() {
        browser.get('/js-components.html#/components/bc-server-table');
    });

    describe('pagination', function()  {
        it('should have 11 rows when no state params are passed (server default)', function() {
            expect($$('.tableRow').count()).toBe(11);
        });

        it('should corrrectly set the limit when a new limit is clicked', function() {
            // click 'view 10' items per page
            $('#pagination > div > a').click();
            $('#pagination [bc-dropdown-menu] > li:nth-child(1) > a').click();

            expect($$('.tableRow').count()).toBe(10);
            browser.getCurrentUrl()
                .then(function(url) {
                    expect(getQueryParams(url)).toEqual({
                        'sort-order': '',
                        'sort-by': '',
                        page: '1',
                        limit: '10'
                    });
                });
        });

        it('should navigate to the next page when the next button is clicked', function() {
            // click 'view 10' items per page
            $('#pagination > div > a').click();
            $('#pagination [bc-dropdown-menu] > li:nth-child(1) > a').click();

            // click next page button
            $('#pagination > li:nth-child(6) > a').click();

            browser.getCurrentUrl()
                .then(function(url) {
                    expect(getQueryParams(url)).toEqual({
                        'sort-order': '',
                        'sort-by': '',
                        page: '2',
                        limit: '10'
                    });
                });
        });

        it('should only show the last rows when viewing the last page', function() {
            // click 'view 10' items per page
            $('#pagination > div > a').click();
            $('#pagination [bc-dropdown-menu] > li:nth-child(1) > a').click();

            // click 'page 4'
            $('#pagination > li:nth-child(5) > a').click();

            expect($$('.tableRow').count()).toBe(3);

            browser.getCurrentUrl()
                .then(function(url) {
                    expect(getQueryParams(url)).toEqual({
                        'sort-order': '',
                        'sort-by': '',
                        page: '4',
                        limit: '10'
                    });
                });
        });

        it('should correctly paginate with deep linked urls', function() {
            browser.get('/js-components.html#/components/bc-server-table?page=4&limit=10');
            expect($$('.tableRow').count()).toBe(3);
        });
    });

    describe('sorting', function() {
        var sortButtonSelector = '#sortByStar > a';

        it('should corrrectly sort the data when a heading is clicked', function() {
            $(sortButtonSelector).click();
            expect($('#row-0 > td:nth-child(3)').getText()).toBe('★');
            $(sortButtonSelector).click();
            expect($('#row-0 > td:nth-child(3)').getText()).toBe('★★★★★');
        });

        it('should corrrectly set the sort-order and sort-by fields when a heading is clicked', function() {
            $(sortButtonSelector).click();
            browser.getCurrentUrl()
                .then(function(url) {
                    expect(getQueryParams(url)).toEqual({
                        'sort-order': 'asc',
                        'sort-by': 'star',
                        'page': '1',
                        'limit': '11'
                    });
                });
            $(sortButtonSelector).click();
            browser.getCurrentUrl()
                .then(function(url) {
                    expect(getQueryParams(url)).toEqual({
                        'sort-order': 'dsc',
                        'sort-by': 'star',
                        'page': '1',
                        'limit': '11'
                    });
                });
        });

        it('should correctly sort with deep linked urls', function() {
            browser.get('/js-components.html#/components/bc-server-table?sort-order=asc&sort-by=star&page=1&limit=11');
            expect($('#row-0 > td:nth-child(3)').getText()).toBe('★');
        });
    });

    describe('filtering', function() {
        it('should update the query params when the filters have changed', function() {
            element(by.model('bcServerTableDemoCtrl.bcServerTable.filters.time')).sendKeys('now');
            $('#updateFilter').click();
            browser.getCurrentUrl()
                .then(function(url) {
                    expect(getQueryParams(url)).toEqual({
                        'sort-order': '',
                        'sort-by': '',
                        'time': 'now',
                        'page': '1',
                        'limit': '11'
                    });
                });
        });

        it('should populate the filters from from the query params on page load', function() {
            browser.get('/js-components.html#/components/bc-server-table?time=rightNow');
            expect(element(by.model('bcServerTableDemoCtrl.bcServerTable.filters.time')).getAttribute('value')).toBe('rightNow');
        });
    });

    it('should sort, page, and filtering at the same time with deep linked urls', function() {
        browser.get('/js-components.html#/components/bc-server-table?sort-order=asc&sort-by=sf-location&page=3&limit=10&time=now');
        expect(element(by.model('bcServerTableDemoCtrl.bcServerTable.filters.time')).getAttribute('value')).toBe('now');
        expect($('#row-0 > td:nth-child(4)').getText()).toBe('Outer Mission');
        expect($('#pagination .pagination-item--current > a').getText()).toBe('3');

    });

});
