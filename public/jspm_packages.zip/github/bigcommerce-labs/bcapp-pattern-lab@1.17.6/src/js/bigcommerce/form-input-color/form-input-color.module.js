/* */ 
angular.module('bcapp-pattern-lab.form-input-color', [
    'bcapp-pattern-lab.form-input-color.directive'
]);
