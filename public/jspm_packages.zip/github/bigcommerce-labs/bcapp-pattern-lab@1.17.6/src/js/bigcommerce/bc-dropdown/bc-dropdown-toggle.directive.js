/* */ 
angular.module('bcapp-pattern-lab.bc-dropdown-toggle.directive', [])
    .directive('bcDropdownToggle', ($compile) => {
        return {
            restrict: 'A',
            terminal: true,
            priority: 1001, // set higher than ng-repeat to prevent double compilation
            require: '^bcDropdown',
            compile: (tElement) => {
                tElement.removeAttr('bc-dropdown-toggle');

                return (scope, element, attrs, bcDropdownCtrl) => {
                    element.attr('dropdown-toggle', '#' + bcDropdownCtrl.getUniqueId());
                    element.attr('aria-controls', bcDropdownCtrl.getUniqueId());
                    element.on('click', bcDropdownCtrl.toggleIsOpen);
                    $compile(element)(scope);
                };
            }
        };
    });
