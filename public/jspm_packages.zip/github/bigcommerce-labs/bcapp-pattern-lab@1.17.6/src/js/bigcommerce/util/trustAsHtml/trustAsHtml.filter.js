/**
 * @name trustAsHtml
 * @description Simple utility filter to run the given html string through angular's $sce.trustAsHtml function.
 *
 * @param {String} text The html string to trust
 * @return {String} An angular-trusted object containing the html
 *
 * @example `<p ng-bind-html="rawHtml | trustAsHtml"></p>`
 */
angular.module('bcapp-pattern-lab.util.trustAsHtml', [])
    .filter('trustAsHtml', function trustAsHtml($sce){
        return function(text) {
            return $sce.trustAsHtml(text);
        };
    });
