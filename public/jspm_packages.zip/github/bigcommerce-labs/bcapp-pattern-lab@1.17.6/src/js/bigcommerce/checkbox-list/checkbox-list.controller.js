/* */ 
angular.module('bcapp-pattern-lab.checkbox-list.controller', [])
    .controller('CheckboxListCtrl', function CheckboxListCtrl($attrs, $element, $log, $parse, $scope) {
        var ctrl = this,
            falseValue = $parse($attrs.ngFalseValue)(ctrl) || false,
            trueValue = $parse($attrs.ngTrueValue)(ctrl) || true,
            ngModel = $element.controller('ngModel');

        init();

        // Getters
        function getModelValue() {
            return ngModel.$modelValue;
        }

        function getValue() {
            return ctrl.value || ctrl.ngValue;
        }

        function getSelectedValues() {
            return ctrl.selectedValues;
        }

        // Setters
        function updateModelValue(modelValue) {
            ngModel.$setViewValue(modelValue);
            ngModel.$commitViewValue();
            ngModel.$render();
        }

        function updateSelectedValues(modelValue) {
            if (modelValue === trueValue) {
                addToSelectedValues();
            } else if (modelValue === falseValue) {
                removeFromSelectedValues();
            }
        }

        function addToSelectedValues() {
            var isIncluded = _.include(ctrl.selectedValues, getValue());

            if (!isIncluded) {
                ctrl.selectedValues.push(getValue());
            }
        }

        function removeFromSelectedValues() {
            var index = _.indexOf(ctrl.selectedValues, getValue());

            if (index !== -1) {
                ctrl.selectedValues.splice(index, 1);
            }
        }

        // Watchers
        function modelValueWatch(modelValue, oldModelValue) {
            var oldSelectedValues,
                selectedValuesChanged;

            // When ngModel value changes
            if (_.isUndefined(modelValue) || modelValue === oldModelValue) {
                return;
            }

            // Retain a shallow copy of selectedValues before update
            oldSelectedValues = ctrl.selectedValues.slice();

            // Update selectedValues
            updateSelectedValues(modelValue);

            // Determine if selectedValues array has changed
            selectedValuesChanged = !!_.xor(ctrl.selectedValues, oldSelectedValues).length;

            // If changed, evoke delegate method (if defined)
            if (ctrl.onChange && selectedValuesChanged) {
                ctrl.onChange({
                    selectedValues: ctrl.selectedValues,
                    oldSelectedValues: oldSelectedValues
                });
            }
        }

        function selectedValuesWatch(selectedValues) {
            // When selectedValues collection changes
            var isIncluded = _.include(selectedValues, getValue()),
                modelValue = getModelValue();

            if (isIncluded && modelValue !== trueValue) {
                updateModelValue(trueValue);
            } else if (!isIncluded && modelValue !== falseValue) {
                updateModelValue(falseValue);
            }
        }

        // Initializer
        function init() {
            if ($attrs.type !== 'checkbox') {
                $log.error('checkbox-list directive: element must be <input type="checkbox">');

                return;
            }

            $scope.$watch(getModelValue, modelValueWatch);
            $scope.$watchCollection(getSelectedValues, selectedValuesWatch);
        }
    });
