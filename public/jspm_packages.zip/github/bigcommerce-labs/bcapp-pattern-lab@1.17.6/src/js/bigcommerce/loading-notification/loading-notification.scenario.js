/* */ 
describe('loading', function() {
    beforeEach(function() {
        browser.get('/js-components.html#/components/loaders');
    });

    it('message should be hiding when no requests are in progress', function() {
        expect(element(by.css('.loadingNotification'))).toHaveClass('ng-hide');
    });

    it('message should display when requests are in progress', function() {
        var ignoreSyncValue = browser.ignoreSynchronization;

        browser.ignoreSynchronization = true;

        expect(element(by.css('.loadingNotification'))).toHaveClass('ng-hide');
        element(by.css('.loading-request')).click();
        expect(element(by.css('.loadingNotification'))).not.toHaveClass('ng-hide');

        browser.controlFlow().execute(function() {
            browser.ignoreSynchronization = ignoreSyncValue;
        });
    });
});
