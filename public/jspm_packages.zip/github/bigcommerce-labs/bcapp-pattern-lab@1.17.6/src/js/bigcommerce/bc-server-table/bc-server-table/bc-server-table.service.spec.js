/* */ 
describe('BcServerTable', function() {
    var $rootScope,
        $q,
        BcServerTable,
        bcServerTable;

    beforeEach(function() {
        module('bcapp-pattern-lab.bc-server-table.service');
    });

    beforeEach(inject(function($injector) {
        $rootScope = $injector.get('$rootScope');
        $q = $injector.get('$q');
        BcServerTable = $injector.get('BcServerTable');

        bcServerTable = new BcServerTable('bc-server-table-instance');
        bcServerTable.resourceCallback = jasmine.createSpy('resourceCallback').and.returnValue($q.when(bcServerTable));
    }));

    describe('fetchResource', function() {
        var promiseValue;

        describe('if successful', function() {
            it('should return a fulfilled promise', function(done) {
                bcServerTable.fetchResource()
                    .then(function(value) {
                        promiseValue = value;
                    })
                    .finally(function() {
                        expect(promiseValue).toEqual(bcServerTable);
                        done();
                    });

                $rootScope.$digest();
            });
        });

        describe('if unsuccessful', function() {
            beforeEach(function() {
                bcServerTable.resourceCallback.and.returnValue($q.reject('Error'));
            });

            it('should return a rejected promise', function(done) {
                bcServerTable.fetchResource()
                    .catch(function(error) {
                        promiseValue = error;
                    })
                    .finally(function() {
                        expect(promiseValue).toEqual('Error');
                        done();
                    });

                $rootScope.$digest();
            });
        });
    });
});
