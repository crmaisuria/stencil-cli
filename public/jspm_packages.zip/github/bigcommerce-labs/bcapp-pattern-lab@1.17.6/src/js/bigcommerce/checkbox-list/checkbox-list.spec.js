/* */ 
describe('checkbox-list directive', function() {
    var $compile,
        $rootScope,
        scope,
        element,
        checkboxes,
        ngModels;

    beforeEach(function() {
        module('bcapp-pattern-lab.checkbox-list.directive');
    });

    beforeEach(inject(function($injector) {
        $compile = $injector.get('$compile');
        $rootScope = $injector.get('$rootScope');

        scope = $rootScope.$new();

        scope.selectedValues = [];
        scope.onChange = jasmine.createSpy('onChange');
        scope.options = [
            {
                id: 1,
                label: 'Option 1'
            },
            {
                id: 2,
                label: 'Option 2'
            },
            {
                id: 3,
                label: 'Option 3'
            }
        ];
    }));

    function compileDirective(scope) {
        var tpl =
            '<div>' +
                '<div ng-repeat="option in options">' +
                    '<input type="checkbox" ' +
                        'value="option.id" ' +
                        'checkbox-list="selectedValues" ' +
                        'checkbox-list-change="onChange()" ' +
                        'ng-model="option.checked"' +
                    '/>' +
                '</div>' +
            '</div>';

        element = $compile(tpl)(scope);

        scope.$digest();

        checkboxes = [
            element[0].querySelectorAll('[ng-model]')[0],
            element[0].querySelectorAll('[ng-model]')[1],
            element[0].querySelectorAll('[ng-model]')[2]
        ];

        ngModels = [
            angular.element(checkboxes[0]).controller('ngModel'),
            angular.element(checkboxes[1]).controller('ngModel'),
            angular.element(checkboxes[2]).controller('ngModel')
        ];
    }

    describe('when checking a checkbox', function() {
        beforeEach(function() {
            compileDirective(scope);

            ngModels[0].$setViewValue(true);
            ngModels[0].$render();
        });

        it('should add itself to the array of selected values', function() {
            expect(scope.selectedValues).toContain(scope.options[0].id);
        });

        it('should invoke delegate method', function() {
            expect(scope.onChange).toHaveBeenCalled();
        });
    });

    describe('when checking a checkbox with non-boolean model value', function() {
        beforeEach(function() {
            scope.options = [
                'Option 1',
                'Option 2',
                'Option 3'
            ];

            compileDirective(scope);

            ngModels[0].$setViewValue(true);
            ngModels[0].$render();
        });

        it('should not update bound model value', function() {
            expect(scope.options[0]).not.toEqual(true);
        });
    });

    describe('when unchecking a checkbox', function() {
        beforeEach(function() {
            scope.options[0].checked = true;
            scope.selectedValues = [scope.options[0].id];

            compileDirective(scope);

            ngModels[0].$setViewValue(false);
            ngModels[0].$render();
        });

        it('should remove itself from the array of selected values', function() {
            expect(scope.selectedValues).not.toContain(scope.options[0].id);
        });

        it('should invoke delegate method', function() {
            expect(scope.onChange).toHaveBeenCalled();
        });
    });

    describe('when selected values are pre-defined', function() {
        beforeEach(function() {
            scope.selectedValues = [
                scope.options[0].id,
                scope.options[1].id
            ];

            compileDirective(scope);
        });

        it('should check relevant checkboxes', function() {
            expect(checkboxes[0].checked).toBeTruthy();
            expect(checkboxes[1].checked).toBeTruthy();
            expect(checkboxes[2].checked).toBeFalsy();
        });
    });
});
