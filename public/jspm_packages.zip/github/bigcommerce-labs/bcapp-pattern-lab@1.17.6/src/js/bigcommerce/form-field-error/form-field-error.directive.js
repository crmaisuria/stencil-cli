/* */ 
angular.module('bcapp-pattern-lab.form-field-error.directive', [])
    .directive('formFieldError', function formFieldErrorDirective($compile) {
        return {
            priority: 10,
            replace: true,
            restrict: 'EA',
            templateUrl: 'src/js/bigcommerce/form-field-error/form-field-error.tpl.html',
            terminal: true,
            transclude: true,
            compile: function formFieldErrorCompile(tElement, tAttrs) {
                // The translate property wipes out our ng-message logic in the post link function
                // The priority and terminal properties above ensure this check occurs
                if (tElement.attr('translate') !== undefined) {
                    throw new SyntaxError(
                        'The translate attribute cannot be used with the form-field-error directive. ' +
                        'Use the translate filter instead (example: {{ "my error message" | translate }}). ' +
                        'Validator: ' + tAttrs.validate
                    );
                }

                return {
                    post: function formFieldErrorPostLink(scope, element, attrs, controllers, transclude) {
                        scope.property = scope.property || attrs.property;

                        transclude(function formFieldErrorTransclude(errorClone) {
                            var labelElement = angular.element('<label>');

                            // ngMessage doesn't play well with dynamic message insertion, translation, or
                            // message expressions, so we build its element up here and inject it into the DOM
                            labelElement.attr('for', scope.property);
                            labelElement.attr('ng-message', attrs.validate);
                            labelElement.attr('role', 'alert');
                            labelElement.addClass('form-inlineMessage');

                            // The error span should already have a translation watcher on it by now, using a filter
                            labelElement.append(errorClone);

                            element.append(labelElement);

                            $compile(element)(scope);
                        });
                    }
                };
            }
        };
    });
