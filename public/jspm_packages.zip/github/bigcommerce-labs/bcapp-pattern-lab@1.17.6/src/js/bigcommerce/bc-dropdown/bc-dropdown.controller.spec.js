/* */ 
describe('bc-dropdown controller', function() {
    var $controller,
        controller,
        $scope;

    function createController() {
        return $controller('BcDropdownController', { $scope: $scope });
    }

    beforeEach(function() {
        module('bcapp-pattern-lab.bc-dropdown.controller');
    });

    beforeEach(inject(function($injector) {
        $controller = $injector.get('$controller');
        $scope = $injector.get('$rootScope').$new();
    }));

    beforeEach(function() {
        controller = createController();
    });

    describe('controller', function() {
        it('should listen for bcDropdownToggle on $rootScope and call closeDropdown when triggeringID does not match directive uniqueId', function() {
            var id = 'someID';
            controller.setIsOpen(true);
            $scope.$emit('bcDropdownToggle', id);
            expect(controller.getIsOpen()).toEqual(false);
        });

        it('should listen for bcDropdownToggle on $rootScope and not call closeDropdown when triggeringID matches directive uniqueId', function() {
            var id = controller.getUniqueId();
            controller.setIsOpen(true);
            $scope.$emit('bcDropdownToggle', id);
            expect(controller.getIsOpen()).toEqual(true);
        });
    });

    describe('closeDropdown method', function() {
        it('should set isOpen to false', function() {
            controller.setIsOpen(true);
            controller.closeDropdown();
            expect(controller.getIsOpen()).toEqual(false);
        });
    });

    describe('getIsOpen method', function() {
        it('should return isOpen', function() {
            expect(controller.getIsOpen()).toEqual(false);

            controller.setIsOpen(true);

            expect(controller.getIsOpen()).toEqual(true);
        });
    });

    describe('getUniqueId method', function() {
        it('should return the same id each time it is called', function () {
            var id1, id2, id3;
            id1 = controller.getUniqueId();
            id2 = controller.getUniqueId();
            id3 = controller.getUniqueId();
            expect([id1, id2, id3]).toEqual([id1, id1, id1]);
        });

        it('should create different ids for each instance of the directive', function () {
            var otherController = createController(),
                id1 = controller.getUniqueId(),
                id2 = otherController.getUniqueId();

            expect(id1).not.toEqual(id2);
        });
    });

    describe('setIsOpen method', function() {
        it('should set isOpen to passed in boolean', function() {
            expect(controller.getIsOpen()).toEqual(false);
            controller.setIsOpen(true);
            expect(controller.getIsOpen()).toEqual(true);
        });
    });

    describe('toggleIsOpen method', function() {
        it('should toggle isOpen', function() {
            controller.toggleIsOpen();
            expect(controller.getIsOpen()).toEqual(true);
        });
    });
});
