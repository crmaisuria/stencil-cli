/* */ 
angular.module('bcapp-pattern-lab.credit-card-types.constant', [])
    .constant('CC_TYPES', {
        'American Express': 'amex',
        'Diners Club': 'dinersclub',
        'Discover': 'discover',
        'MasterCard': 'mastercard',
        'Visa': 'visa',
    });
