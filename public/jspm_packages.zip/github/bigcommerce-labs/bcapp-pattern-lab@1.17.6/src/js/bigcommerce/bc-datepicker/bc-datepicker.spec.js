/* */ 
describe('Directive: bc-datepicker', function () {
    var BC_DATEPICKER_DEFAULTS,
        $compile,
        $scope;

    beforeEach(module('bcapp-pattern-lab-templates'));
    beforeEach(module('bcapp-pattern-lab.bc-datepicker'));
    beforeEach(module('bcapp-pattern-lab.bc-datepicker.constants'));

    beforeEach(inject(function($injector) {
        $compile = $injector.get('$compile');
        $scope = $injector.get('$rootScope').$new();
        BC_DATEPICKER_DEFAULTS = $injector.get('BC_DATEPICKER_DEFAULTS');
    }));

    function compileDirective(scope) {
        var element = angular.element('<input ng-model="testDate" options="options" bc-datepicker />'),
            compiledElement = $compile(element)(scope);

        scope.$digest();
        return compiledElement.isolateScope();
    }

    describe('On data event', function() {
        it('should set ngModel to the passed value', function() {
            var isolateScope = compileDirective($scope),
                date = new Date();

            expect($scope.testDate).toBe(undefined);
            isolateScope.calendar.emit('data', date);
            expect($scope.testDate).toBe(date);
        });
    });

    describe('Default options', function() {
        it('should work even if we do not pass any options', function() {
            var isolateScope;

            $scope.options = undefined;
            isolateScope = compileDirective($scope);

            expect(isolateScope.options).toBeDefined();
        });

        it('should set the big-commerce default options if not passed', function() {
            var isolateScope = compileDirective($scope);

            expect(isolateScope.options).toEqual(BC_DATEPICKER_DEFAULTS);
        });

        it('should not overwrite options passed by user', function() {
            var isolateScope;

            $scope.options = {
                time: true
            };

            isolateScope = compileDirective($scope);

            expect(isolateScope.options.time).toBe(true);
        });
    });
});
