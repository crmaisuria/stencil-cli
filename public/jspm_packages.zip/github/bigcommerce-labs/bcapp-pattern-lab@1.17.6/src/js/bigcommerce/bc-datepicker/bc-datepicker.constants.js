/* globals moment */
angular.module('bcapp-pattern-lab.bc-datepicker.constants', [])
    .constant('BC_DATEPICKER_DEFAULTS', {
        dayFormat: 'D',
        inputFormat: moment.localeData().longDateFormat('L'),
        styles: {
            back: 'datepicker-back',
            container: 'datepicker',
            date: 'datepicker-date',
            dayBody: 'datepicker-days-body',
            dayBodyElem: 'datepicker-day',
            dayConcealed: 'datepicker-day-concealed',
            dayDisabled: 'is-disabled',
            dayHead: 'datepicker-days-head',
            dayHeadElem: 'datepicker-day-name',
            dayPrevMonth: 'datepicker-day-prev-month',
            dayNextMonth: 'datepicker-day-next-month',
            dayRow: 'datepicker-days-row',
            dayTable: 'datepicker-days',
            month: 'datepicker-month',
            monthLabel: 'datepicker-month',
            next: 'datepicker-next',
            positioned: 'datepicker-attachment',
            selectedDay: 'is-selected',
            selectedTime: 'datepicker-time-selected',
            time: 'datepicker-time',
            timeList: 'datepicker-time-list',
            timeOption: 'datepicker-time-option'
        },
        time: false,
        weekdayFormat: 'short'
    });
