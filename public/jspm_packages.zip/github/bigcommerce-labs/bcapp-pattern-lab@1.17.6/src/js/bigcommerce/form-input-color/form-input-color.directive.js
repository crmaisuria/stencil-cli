/* */ 
angular.module('bcapp-pattern-lab.form-input-color.directive', [
    'bcapp-pattern-lab.form-input-color.controller',
])

    .directive('formInputColor', function formInputColorDirective($document) {
        return {
            bindToController: true,
            controller: 'FormInputColorCtrl',
            controllerAs: 'formInputColorCtrl',
            require: ['formInputColor', '^ngModel'],
            restrict: 'E',
            scope: {
                labelText: '=',
                palette: '=',
                placeholderText: '=',
            },
            templateUrl: 'src/js/bigcommerce/form-input-color/form-input-color.tpl.html',

            compile: function formInputColorDirectiveCompile(tElement) {
                tElement.addClass('form-inputColor');

                return function formInputColorDirectiveLink($scope, element, attrs, ctrls) {
                    const ctrl = ctrls[0];
                    const ngModelCtrl = ctrls[1];

                    ctrl.setModelCtrl(ngModelCtrl);

                    $document.on('keydown', keydownEventHandler);
                    $document.on('mousedown', mouseDownEventHandler);

                    $scope.$on('$destroy', () => {
                        $document.off('mousedown', mouseDownEventHandler);
                        $document.off('keydown', keydownEventHandler);
                    });

                    function keydownEventHandler ($event) {
                        if ($event.which === 27) {
                            $scope.$apply(() => {
                                ctrl.hidePicker();
                            });
                        }
                    }

                    function mouseDownEventHandler($event) {
                        if (element[0].contains($event.target)) {
                            return;
                        }
                        $scope.$apply(() => {
                            ctrl.hidePicker();
                        });
                    }


                };
            }
        };
    });
