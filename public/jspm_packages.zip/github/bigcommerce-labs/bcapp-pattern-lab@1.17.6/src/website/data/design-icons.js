/* */ 
"format global";
var IconsFromFolder = require('./utils/IconsFromFolders'),
    iconsFromFolder = new IconsFromFolder(),
    config = require('../../../gulp/config'),
    designIconPath = config.icons.src + '/design-icons';

module.exports = {
    designIcons: iconsFromFolder.getIcons(designIconPath)
};
