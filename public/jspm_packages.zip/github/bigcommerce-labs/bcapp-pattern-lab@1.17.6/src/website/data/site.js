/* */ 
"format global";
'use strict';

var currentVersion = require('../../../package.json').version;

module.exports = {
    title: 'Bigcommerce Pattern Lab',
    version: currentVersion
};
