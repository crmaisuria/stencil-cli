/* */ 
angular.module('website.alerts.controller', [])

    .controller('AlertsCtrl', function($scope) {
        $scope.alerts = [
            { msg: 'Generic alert' },
            { type: 'info', msg: 'Informational alert' },
            { type: 'success', msg: 'Success alert' },
            { type: 'warning', msg: 'Warning alert' },
            { type: 'error', msg: 'Error alert' }
        ];

        $scope.openAlert =  { type: 'error', msg: 'Error alert in a panel' };

        $scope.addAlert = function() {
            $scope.alerts.push({msg: 'Another generic alert!'});
        };

        $scope.closeAlert = function(index) {
            $scope.alerts.splice(index, 1);
        };
    });
