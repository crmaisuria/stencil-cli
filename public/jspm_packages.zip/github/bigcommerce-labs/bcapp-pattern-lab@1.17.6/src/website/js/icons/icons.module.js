/* */ 
angular.module('website.icons', [
    'website.icons.directive'
]);
