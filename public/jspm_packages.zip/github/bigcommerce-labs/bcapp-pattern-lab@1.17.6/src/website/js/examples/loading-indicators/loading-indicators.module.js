/* */ 
angular.module('website.loading-indicators', [
    'website.loading-indicators.state'
]);
