/* */ 
angular.module('website.accordion.state', [
    'ui.router',
    'website.accordion.controller'
])

    .config(function($stateProvider) {
        $stateProvider
            .state('components.accordion', {
                url: '/accordion',
                templateUrl: 'src/website/js/examples/accordion/accordion.tpl.html',
                controller: 'AccordionCtrl as accordionCtrl'
            });
    });
