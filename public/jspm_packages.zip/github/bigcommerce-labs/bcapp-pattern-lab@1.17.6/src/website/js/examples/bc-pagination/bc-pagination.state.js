/* */ 
angular.module('website.bc-pagination.state', [
    'ui.router',
    'website.bc-pagination.controller'
])

    .config(function($stateProvider) {
        $stateProvider
            .state('components.bc-pagination', {
                url: '/bc-pagination',
                templateUrl: 'src/website/js/examples/bc-pagination/bc-pagination.tpl.html',
                controller: 'BcPaginationCtrl as bcPaginationCtrl'
            });
    });
