/* */ 
angular.module('website.bc-server-table.controller', [
    'ui.router',
    'bcapp-pattern-lab.bc-server-table',
    'e2e-backend'
])

    .controller('BcServerTableDemoCtrl', function($scope, $state, bcServerTableFactory, dataTable, DEMO_TABLE_ID) {
        var ctrl = this;

        ctrl.clearTable = clearTable;
        ctrl.bcServerTable = bcServerTableFactory.get(DEMO_TABLE_ID);

        // This needs to be here until the pagination directive is updated
        // to preserve context when calling the on-change function.
        ctrl.bcServerTable.updatePage = _.bind(ctrl.bcServerTable.updatePage, ctrl.bcServerTable);

        function clearTable($event) {
            $event.preventDefault();
            $state.go($state.current.name, { page: 1 }, { inherit: false });
        }
    });
