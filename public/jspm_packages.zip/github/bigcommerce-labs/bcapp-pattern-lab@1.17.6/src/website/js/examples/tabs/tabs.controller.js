/* */ 
angular.module('website.tabs.controller', [])

    .controller('TabsCtrl', function() {
        var ctrl = this;

        ctrl.tabs = [
            { title:'Dynamic Title 1', content:'Dynamic content 1' },
            { title:'Dynamic Title 2', content:'Dynamic content 2' }
        ];

        ctrl.tabClicked = function tabClicked() {
            console.log('tab clicked!');
        };
    });
