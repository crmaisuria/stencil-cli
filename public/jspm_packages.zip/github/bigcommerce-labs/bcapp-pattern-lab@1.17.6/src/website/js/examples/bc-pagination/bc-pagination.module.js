/* */ 
angular.module('website.bc-pagination', [
    'website.bc-pagination.state'
]);
