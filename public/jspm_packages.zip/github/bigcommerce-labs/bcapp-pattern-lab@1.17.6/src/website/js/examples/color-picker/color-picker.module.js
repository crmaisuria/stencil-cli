/* */ 
angular.module('website.color-picker-example', [
    'website.color-picker-example.state'
]);
