/* */ 
angular.module('website.bc-pagination.controller', [])

    .controller('BcPaginationCtrl', function($scope, $log) {
        $scope.totalItems = 200;
        $scope.currentPage = 1;
        $scope.maxSize = 5;
        $scope.itemsPerPage = 10;
        $scope.showLimits = false;

        $scope.onSelectPage = function(newValues) {
            $log.log('New Values Combo: ', newValues);
        };

        $scope.setPage = function(pageNo) {
            $scope.currentPage = pageNo;
        };

        $scope.customLimits = [10, 20, 30, 100];
    });
