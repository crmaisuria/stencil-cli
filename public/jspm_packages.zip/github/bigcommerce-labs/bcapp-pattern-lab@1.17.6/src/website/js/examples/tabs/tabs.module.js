/* */ 
angular.module('website.tabs', [
    'website.tabs.state'
]);
