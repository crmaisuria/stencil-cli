/* */ 
angular.module('website.bc-server-table', [
    'website.bc-server-table.state'
]);
