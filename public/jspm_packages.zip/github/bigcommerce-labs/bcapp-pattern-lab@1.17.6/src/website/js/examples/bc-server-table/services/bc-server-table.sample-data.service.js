/* */ 
angular.module('website.bc-server-table.sample-data.service', [])
    .factory('sampleData', function sampleData($http) {
        var service = {
            getSampleData: getSampleData
        };

        function getSampleData(queryParams) {
            return $http.get('/table.json', {
                params: queryParams
            })
                .then(function getSampleDataSuccess(response) {
                    return {
                        rows: response.data.rows,
                        pagination: {
                            page: response.data.pagination.page,
                            limit: response.data.pagination.limit,
                            total: response.data.pagination.numItems
                        }
                    };
                });
        }

        return service;
    });
