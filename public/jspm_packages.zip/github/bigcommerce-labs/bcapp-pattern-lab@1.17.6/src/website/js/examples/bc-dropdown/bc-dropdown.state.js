/* */ 
angular.module('website.bc-dropdown.state', [
    'ui.router'
])

    .config(function($stateProvider) {
        $stateProvider
            .state('components.bc-dropdown', {
                url: '/bc-dropdown',
                templateUrl: 'src/website/js/examples/bc-dropdown/bc-dropdown.tpl.html'
            });
    });
