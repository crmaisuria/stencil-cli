/* */ 
angular.module('website.icons.directive', [
        'website.icons.controller'
    ])
    .directive('iconsList', function bcIconDirective() {
        var directive = {
            restrict: 'E',
            templateUrl: 'src/website/js/icons/icons.tpl.html',
            controller: 'IconsCtrl as iconsCtrl'
        };
        return directive;
    });
