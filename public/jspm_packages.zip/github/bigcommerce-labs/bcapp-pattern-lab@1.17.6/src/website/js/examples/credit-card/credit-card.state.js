/* */ 
angular.module('website.credit-card.state', [
    'ui.router',
    'website.credit-card.controller'
])

    .config(function($stateProvider) {
        $stateProvider
            .state('components.credit-card', {
                url: '/credit-card',
                templateUrl: 'src/website/js/examples/credit-card/credit-card.tpl.html',
                controller: 'CreditCardCtrl as creditCardCtrl'
            });
    });
