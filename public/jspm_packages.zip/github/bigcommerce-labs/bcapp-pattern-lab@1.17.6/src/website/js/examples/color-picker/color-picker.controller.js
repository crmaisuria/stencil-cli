/* */ 
angular.module('website.color-picker-example.controller', [])

    .controller('ColorPickerExampleCtrl', function($scope) {
        $scope.modelValue = '#cccccc';

        $scope.palette = [
            '#00ABC9',
            '#95db89',
            '#ffb800',
            '#db636b',
            '#556273',
            '#232831',
            '#b186cb',
            '#ff8800',
            '#3e62a1',
            '#e89fae',
            '#6eccfc',
        ];

        $scope.inputModelValue = '#6eccfc';
        $scope.inputLabelText = 'Input Label Text';
        $scope.inputPlaceholderText = 'Input Placeholder Text';
        $scope.inputPalette = [
            '#00ABC9',
            '#E5F6F9',
            '#95DB89',
            '#FFB800'
        ];
    });
