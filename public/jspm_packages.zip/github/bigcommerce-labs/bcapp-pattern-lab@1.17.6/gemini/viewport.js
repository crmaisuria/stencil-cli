/* */ 
"format global";
var viewportSizes = {
    large: {
        height: 1200,
        width: 1281
    },
    xsmall: {
        height: 1200,
        width: 481
    }
};

function largeViewport(actions) {
    return actions
        .setWindowSize(viewportSizes.xsmall.width, viewportSizes.xsmall.height)
        .wait(500);
}

function xsmallViewport(actions) {
    return actions
        .setWindowSize(viewportSizes.xsmall.width, viewportSizes.xsmall.height)
        .wait(500);
}

module.exports = {
    largeViewport: largeViewport,
    xsmallViewport: xsmallViewport
};
