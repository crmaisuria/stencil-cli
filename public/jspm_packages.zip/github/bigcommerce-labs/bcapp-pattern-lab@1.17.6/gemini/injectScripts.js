/* */ 
"format global";
/*
 * Inject helper functions into the page so that they can be called inside `executeJS` context
 */
function injectScripts(window) {
    var document = window.document,
        scriptId = 'geminiScriptInjection';

    function stubImageSrc(selector, src) {
        var elements = document.querySelectorAll(selector),
            newSrc;

        // Replace the original image with a solid rect
        newSrc = src || [
            'data:image/svg+xml,',
            '<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="1000">',
            '   <rect width="100%" height="100%" fill="#efefef" />',
            '</svg>'
        ].join('');

        Array.prototype.slice.call(elements).forEach(function(element) {
            element.src = newSrc;
        });
    }

    function createScriptTag(functions) {
        var script = document.createElement('script');

        script.id = scriptId;
        script.innerHTML = functions.map(function(func) {
            return func.toString();
        }).join('\n');

        return script;
    }

    if (document.getElementById(scriptId)) {
        return;
    }

    document.body.appendChild(createScriptTag([
        stubImageSrc
    ]));
}

module.exports = injectScripts;
