/* */ 
"format global";
var fs = require('fs'),
    directory = __dirname + '/tests';

fs.readdirSync(directory).forEach(function requireAll(file) {
    require(directory + '/' + file);
});
