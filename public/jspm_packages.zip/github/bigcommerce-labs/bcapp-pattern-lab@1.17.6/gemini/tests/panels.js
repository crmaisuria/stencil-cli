/* */ 
"format global";
var gemini = require('gemini');

gemini.suite('panels', function(suite) {
    suite.setUrl('/panels.html');

    gemini.suite('panel minor', function(suite) {
        suite
            .setCaptureElements('#labExamplePanelMinor .panel')
            .capture('normal');
    });

    gemini.suite('panel', function(suite) {
        suite
            .setCaptureElements('#labExamplePanel .panel')
            .capture('normal');
    });
});
