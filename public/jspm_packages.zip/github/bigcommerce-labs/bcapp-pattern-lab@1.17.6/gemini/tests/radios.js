/* */ 
"format global";
var gemini = require('gemini');

gemini.suite('radios', function(suite) {
    suite.setUrl('/forms.html');

    gemini.suite('radio', function(suite) {
        suite
            .setCaptureElements('#labExampleRadio .form-fieldset')
            .capture('normal')
            .capture('selected', function(actions) {
                actions.mouseMove('#labExampleRadio .form-radio');
            });
    });
});
