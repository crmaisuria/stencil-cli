/* */ 
"format global";
var gemini = require('gemini');

gemini.suite('buttons', function(suite) {
    suite.setUrl('/buttons.html');

    gemini.suite('button', function(suite) {
        suite
            .setCaptureElements('#labExampleButton')
            .capture('normal')
            .capture('hover', function(actions) {
                actions.mouseMove('#labExampleButton .button', { x: 10, y: 10 });
            });
    });

    gemini.suite('button state', function(suite) {
        suite
            .setCaptureElements('#labExampleButtonState')
            .capture('normal');
    });

    gemini.suite('button disabled state', function(suite) {
        suite
            .setCaptureElements('#labExampleButtonStateDisabled')
            .capture('normal');
    });

    gemini.suite('button size', function(suite) {
        suite
            .setCaptureElements('#labExampleButtonSize')
            .capture('normal');
    });

    gemini.suite('button icon', function(suite) {
        suite
            .setCaptureElements('#labExampleButtonIcon')
            .capture('normal');
    });
});
