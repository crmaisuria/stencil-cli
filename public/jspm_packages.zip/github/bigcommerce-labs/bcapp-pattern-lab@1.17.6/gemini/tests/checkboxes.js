/* */ 
"format global";
var gemini = require('gemini');

gemini.suite('checkboxes', function(suite) {
    suite.setUrl('/forms.html');

    gemini.suite('checkbox', function(suite) {
        suite
            .setCaptureElements('#labExampleCheckbox .form-fieldset')
            .capture('normal')
            .capture('selected', function(actions) {
                actions.mouseMove('#labExampleCheckbox .form-checkbox');
            });
    });
});
