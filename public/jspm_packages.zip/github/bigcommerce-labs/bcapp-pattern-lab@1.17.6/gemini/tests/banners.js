/* */ 
"format global";
var gemini = require('gemini');

gemini.suite('banners', function(suite) {
    suite.setUrl('/banners.html');

    gemini.suite('banner', function(suite) {
        suite
            .setCaptureElements('#labExampleBanner .banner')
            .capture('normal');
    });
});
