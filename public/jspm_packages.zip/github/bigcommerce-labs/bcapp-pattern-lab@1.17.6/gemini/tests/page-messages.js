/* */ 
"format global";
var gemini = require('gemini'),
    injectScripts = require('../injectScripts');

gemini.suite('page-messages', function(suite) {
    suite
        .setUrl('/page-message.html')
        .before(function(actions) {
            actions
                .executeJS(injectScripts)
                .executeJS(function(window) {
                    window.stubImageSrc('.pageMessage img');
                });
        });

    gemini.suite('page message', function(suite) {
        suite
            .setCaptureElements('#labExamplePageMessage')
            .capture('normal');
    });

    gemini.suite('page message status', function(suite) {
        suite
            .setCaptureElements('#labExamplePageMessageStatus')
            .capture('normal');
    });

    gemini.suite('page message upsell', function(suite) {
        suite
            .setCaptureElements('#labExamplePageMessageUpsell')
            .capture('normal');
    });
});
