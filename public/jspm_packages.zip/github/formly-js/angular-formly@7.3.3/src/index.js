import index from './index.common'
export default index
