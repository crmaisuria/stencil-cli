define(["github:formly-js/angular-formly@7.3.3/dist/formly"], function(main) {
  return main;
});